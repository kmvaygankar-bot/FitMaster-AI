import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini client (Only if key is available)
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  aiClient = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Caching mechanism for motivational quotes to prevent exceeding Gemini API quotas (limit: 20 per day)
interface CachedQuote {
  quote: string;
  author: string;
}

let cachedQuote: CachedQuote | null = null;
let cachedQuoteTime: number = 0;
const QUOTE_CACHE_DURATION = 12 * 60 * 60 * 1000; // Cache for 12 hours


async function startServer() {
  const app = express();
  app.use(express.json());

  // API Endpoint: Generate Workout Plan
  app.post('/api/workout-plan', async (req, res) => {
    const { age, gender, height, weight, goal, equipment, experience } = req.body;

    if (!goal) {
      return res.status(400).json({ error: 'Goal is required' });
    }

    const prompt = `Create a highly tailored 7-day fitness workout plan for a user with the following profile:
- Age: ${age || 'Not specified'}
- Gender: ${gender || 'Not specified'}
- Height: ${height || 'Not specified'} cm
- Weight: ${weight || 'Not specified'} kg
- Goal: ${goal}
- Available Equipment: ${equipment || 'Bodyweight only'}
- Workout Experience: ${experience || 'Beginner'}

Provide an engaging and structured 7-day routine in English. Ensure that you return a valid, compact JSON matching the requested schema. Keep descriptions, instructions, and tips extremely short (max 12 words) to prevent truncation. Do not exceed 4 exercises per active day.`;

    try {
      if (aiClient) {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: prompt,
          config: {
            systemInstruction: "You are an elite certified personal trainer and fitness coach. Design realistic, safe, and effective 7-day training cycles. Keep descriptions, instructions, and tips under 10-12 words. Maximum 4 exercises for active days, and 0 exercises for rest/recovery days. Be extremely concise. Avoid any conversational filler inside the JSON values.",
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                planName: { type: Type.STRING, description: "Name of the workout plan, max 6 words" },
                weeklyFocus: { type: Type.STRING, description: "Weekly fitness focus, max 15 words" },
                estimatedDailyDuration: { type: Type.STRING, description: "Average daily duration, e.g., '30-45 mins'" },
                targetCaloriesPerDay: { type: Type.INTEGER, description: "Target active calories to burn per workout day, e.g., 300" },
                days: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      dayNumber: { type: Type.INTEGER, description: "Day index 1 to 7" },
                      title: { type: Type.STRING, description: "Title of the workout, e.g. 'Push Day', 'Active Rest'" },
                      focus: { type: Type.STRING, description: "Focus muscle groups" },
                      restDay: { type: Type.BOOLEAN, description: "true if rest day" },
                      description: { type: Type.STRING, description: "Extremely short summary, max 10 words" },
                      exercises: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            name: { type: Type.STRING, description: "Name of exercise" },
                            sets: { type: Type.INTEGER, description: "Number of sets, e.g., 3" },
                            reps: { type: Type.STRING, description: "e.g., '12 reps' or '45 seconds'" },
                            restAfterSet: { type: Type.STRING, description: "e.g., '45s' or '60s'" },
                            instructions: { type: Type.STRING, description: "Step-by-step cue, max 12 words" },
                            tips: { type: Type.STRING, description: "Form warning, max 10 words" }
                          },
                          required: ["name", "sets", "reps", "instructions"]
                        }
                      }
                    },
                    required: ["dayNumber", "title", "restDay", "description"]
                  }
                }
              },
              required: ["planName", "weeklyFocus", "estimatedDailyDuration", "targetCaloriesPerDay", "days"]
            }
          }
        });

        if (response.text) {
          const planData = JSON.parse(response.text.trim());
          return res.json(planData);
        }
      }
      
      // Fallback local workout plans generator if Gemini is unavailable
      console.log('Gemini client not initialized or empty text. Using robust local fallback generator.');
      const fallbackPlan = generateLocalFallbackPlan(goal, equipment, experience);
      res.json(fallbackPlan);

    } catch (error: any) {
      const errMsg = error?.message || String(error);
      const isQuota = errMsg.includes('429') || errMsg.includes('Quota') || errMsg.includes('quota') || errMsg.includes('RESOURCE_EXHAUSTED');
      if (isQuota) {
        console.log('Gemini API Quota Exceeded (429) while generating workout plan. Serving robust local dynamic fallback plan.');
      } else {
        console.log('Gemini workout plan generation status: Unavailable');
      }
      // Fallback to local generator on error
      const fallbackPlan = generateLocalFallbackPlan(goal, equipment, experience);
      res.json(fallbackPlan);
    }
  });

  // API Endpoint: Daily Motivational Quote
  app.get('/api/motivation', async (req, res) => {
    const now = Date.now();
    
    // Check if we have a valid cached quote
    if (cachedQuote && (now - cachedQuoteTime < QUOTE_CACHE_DURATION)) {
      return res.json(cachedQuote);
    }

    try {
      if (aiClient) {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: 'Give me one high-energy motivational quote for working out. Keep it under 25 words. Return JSON containing "quote" and "author".',
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                quote: { type: Type.STRING },
                author: { type: Type.STRING }
              },
              required: ["quote", "author"]
            }
          }
        });

        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          if (parsed && parsed.quote) {
            cachedQuote = parsed;
            cachedQuoteTime = now;
            return res.json(parsed);
          }
        }
      }
    } catch (e: any) {
      const errMsg = e?.message || String(e);
      const isQuota = errMsg.includes('429') || errMsg.includes('Quota') || errMsg.includes('quota') || errMsg.includes('RESOURCE_EXHAUSTED');
      if (isQuota) {
        console.log('Gemini API Quota Exceeded (429) while fetching motivational quote. Serving local fallback quote.');
      } else {
        console.log('Gemini motivation quote status: Unavailable');
      }
      
      // If we already have a cached quote (even if expired), keep using it to avoid spamming on 429
      if (cachedQuote) {
        // Extend the cache time slightly (e.g. 15 minutes) so we don't hammer the API on every refresh
        cachedQuoteTime = now - QUOTE_CACHE_DURATION + (15 * 60 * 1000); 
        return res.json(cachedQuote);
      }
    }

    const quotes = [
      { quote: "Your body can stand almost anything. It's your mind that you have to convince.", author: "Unknown" },
      { quote: "Success starts with self-discipline.", author: "Dwayne Johnson" },
      { quote: "The only bad workout is the one that didn't happen.", author: "Unknown" },
      { quote: "Action is the foundational key to all success.", author: "Pablo Picasso" },
      { quote: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" }
    ];
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    // Cache the fallback quote for 1 hour to prevent hitting the API on subsequent immediate loads during 429 cooling down
    cachedQuote = randomQuote;
    cachedQuoteTime = now - QUOTE_CACHE_DURATION + (1 * 60 * 60 * 1000); 
    
    res.json(randomQuote);
  });

  // Mount Vite dev server in non-production mode, otherwise serve static dist
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const port = process.env.PORT || 3000;
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
}

// Local dynamic plan generator helper
function generateLocalFallbackPlan(goal: string, equipment: string, experience: string) {
  const isGym = equipment && equipment.toLowerCase().includes('gym') || equipment.toLowerCase().includes('dumbbell');
  const level = experience || 'Beginner';

  const defaultExercisesMap: Record<string, Array<{name: string, instructions: string, reps: string, sets: number, restAfterSet: string, tips: string}>> = {
    'Weight Loss': [
      { name: 'Jumping Jacks', sets: 3, reps: '45 seconds', restAfterSet: '30s', instructions: 'Stand with feet together, jump spreading legs and clapping hands overhead, then return.', tips: 'Keep a fast and steady pace.' },
      { name: 'Bodyweight Squats', sets: 4, reps: '15 reps', restAfterSet: '45s', instructions: 'Lower your hips down and back while keeping your spine straight and chest up.', tips: 'Squeeze glutes at the top.' },
      { name: 'Burpees', sets: 3, reps: '10 reps', restAfterSet: '60s', instructions: 'Drop into squat, kick feet back, do a pushup, jump feet back to squat, then jump up.', tips: 'Maintain form even when tired.' },
      { name: 'Mountain Climbers', sets: 3, reps: '40 seconds', restAfterSet: '30s', instructions: 'From high plank, alternately drive knees to chest rapidly as if running.', tips: 'Keep core tight, hips level.' },
      { name: 'Plank Hold', sets: 3, reps: '60 seconds', restAfterSet: '45s', instructions: 'Hold a forearm plank with elbows under shoulders and body in straight line.', tips: 'Don\'t let hips sag.' }
    ],
    'Six Pack': [
      { name: 'Crunches', sets: 4, reps: '20 reps', restAfterSet: '30s', instructions: 'Lie on back, knees bent, raise shoulders off floor using abdominal strength.', tips: 'Squeeze at the peak, do not pull your neck.' },
      { name: 'Leg Raises', sets: 3, reps: '15 reps', restAfterSet: '45s', instructions: 'Lie flat, raise legs slowly to 90 degrees, then lower them without touching the floor.', tips: 'Keep lower back pressed into floor.' },
      { name: 'Russian Twists', sets: 3, reps: '20 reps each side', restAfterSet: '30s', instructions: 'Sit with knees bent, feet slightly off ground, rotate torso side to side.', tips: 'Focus on twisting from the obliques.' },
      { name: 'Bicycle Crunches', sets: 3, reps: '20 reps total', restAfterSet: '30s', instructions: 'Alternate touching left elbow to right knee, and right elbow to left knee.', tips: 'Maintain slow, controlled rotations.' },
      { name: 'Plank Knee-to-Elbow', sets: 3, reps: '12 reps each side', restAfterSet: '45s', instructions: 'From high plank, bring left knee to left elbow, return, repeat on right side.', tips: 'Engage side obliques.' }
    ],
    'Chest': [
      { name: isGym ? 'Dumbbell Bench Press' : 'Standard Pushups', sets: 4, reps: '12 reps', restAfterSet: '60s', instructions: isGym ? 'Lie on bench, press dumbbells upwards from chest level.' : 'Do standard chest pushups with elbows at 45 degree angles.', tips: 'Control the eccentric phase.' },
      { name: isGym ? 'Incline Dumbbell Press' : 'Decline Pushups', sets: 3, reps: '12 reps', restAfterSet: '60s', instructions: isGym ? 'Press dumbbells upwards on 30-degree incline bench.' : 'Elevate your feet on a chair and perform pushups to target upper chest.', tips: 'Keep shoulders retracted.' },
      { name: isGym ? 'Dumbbell Chest Flyes' : 'Wide Pushups', sets: 3, reps: '12 reps', restAfterSet: '45s', instructions: isGym ? 'Open dumbbells out wide in flying motion while lying on bench.' : 'Place hands wider than shoulder width to target outer chest chest fibers.', tips: 'Focus on chest contraction.' },
      { name: 'Diamond Pushups', sets: 3, reps: '10 reps', restAfterSet: '45s', instructions: 'Form a diamond with your index fingers and thumbs on the floor under your chest.', tips: 'Engages inner chest and triceps.' }
    ],
    'Arms': [
      { name: isGym ? 'Dumbbell Bicep Curls' : 'Chinups (or Door Pull Curls)', sets: 4, reps: '12 reps', restAfterSet: '45s', instructions: isGym ? 'Curl dumbbells towards shoulders, keeping elbows locked at your side.' : 'Perform pullups with palms facing you.', tips: 'Do not swing your body.' },
      { name: 'Tricep Dips', sets: 4, reps: '15 reps', restAfterSet: '45s', instructions: 'Use a bench or chair, lower hips down keeping back close to the support.', tips: 'Keep chest upright, extend elbows fully.' },
      { name: isGym ? 'Hammer Curls' : 'Plank Up-Downs', sets: 3, reps: '12 reps', restAfterSet: '45s', instructions: isGym ? 'Curl dumbbells with neutral palms-facing-each-other grip.' : 'Go from high plank to forearm plank and back up.', tips: 'Maintains forearm and bicep thickness.' },
      { name: isGym ? 'Overhead Tricep Extension' : 'Pike Pushups', sets: 3, reps: '12 reps', restAfterSet: '60s', instructions: isGym ? 'Hold dumbbell with both hands overhead, lower behind neck and press back up.' : 'Perform pushups with hips high in the air to engage shoulders and triceps.', tips: 'Keep elbows tucked in.' }
    ],
    'Legs': [
      { name: isGym ? 'Goblet Squats' : 'Air Squats', sets: 4, reps: '15 reps', restAfterSet: '60s', instructions: 'Perform deep squats with optimal knee-to-toe alignment.', tips: 'Keep weight on heels.' },
      { name: 'Walking Lunges', sets: 3, reps: '12 steps per leg', restAfterSet: '45s', instructions: 'Step forward, bending knees to 90 degrees, repeat in continuous forward steps.', tips: 'Don\'t let front knee pass toes.' },
      { name: isGym ? 'Dumbbell Romanian Deadlifts' : 'Single-Leg Glute Bridges', sets: 3, reps: '12 reps per leg', restAfterSet: '45s', instructions: 'Lie on back, lift one leg, drive hips upwards by pressing through the other heel.', tips: 'Engage hamstrings and glutes.' },
      { name: 'Calf Raises', sets: 4, reps: '20 reps', restAfterSet: '30s', instructions: 'Stand on edge of a step, raise onto tiptoes, and stretch calves at bottom.', tips: 'Hold at peak for 1 second.' }
    ],
    'Full Body': [
      { name: 'Squat to Press', sets: 4, reps: '12 reps', restAfterSet: '60s', instructions: isGym ? 'Perform squat, then press dumbbells overhead as you stand.' : 'Perform bodyweight squat, then reach hands overhead high as you jump slightly.', tips: 'Fluid continuous movement.' },
      { name: 'Pushups', sets: 4, reps: '12 reps', restAfterSet: '45s', instructions: 'Standard floor pushups.', tips: 'Maintain solid line plank posture.' },
      { name: isGym ? 'Dumbbell Rows' : 'Door Frame Rows', sets: 3, reps: '12 reps each side', restAfterSet: '45s', instructions: 'Pull weights or door frame towards your chest to engage back.', tips: 'Squeeze shoulder blades.' },
      { name: 'Lunges', sets: 3, reps: '10 reps per leg', restAfterSet: '45s', instructions: 'Alternating forward lunges.', tips: 'Keep chest upright.' },
      { name: 'Burpees', sets: 3, reps: '8 reps', restAfterSet: '60s', instructions: 'Full body movement.', tips: 'Maximize power on jump.' }
    ],
    'Flexibility': [
      { name: 'Downward Dog', sets: 3, reps: '45 seconds', restAfterSet: '15s', instructions: 'Form inverted V with body, pushing heels down and chest towards thighs.', tips: 'Lengthen the spine.' },
      { name: 'Cobra Stretch', sets: 3, reps: '30 seconds', restAfterSet: '15s', instructions: 'Lie face down, press chest upwards while keeping pelvis on floor.', tips: 'Relax shoulders down.' },
      { name: 'Child\'s Pose', sets: 3, reps: '60 seconds', restAfterSet: '15s', instructions: 'Kneel and reach arms forward, sitting hips back onto heels.', tips: 'Breathe deeply into the back.' },
      { name: 'Hamstring Reach', sets: 3, reps: '45 seconds', restAfterSet: '15s', instructions: 'Sit with legs straight, fold forward from hips to reach toes.', tips: 'Keep spine straight.' }
    ],
    'Kegel Exercises': [
      { name: 'Quick Squeezes', sets: 3, reps: '10 reps (2s hold)', restAfterSet: '30s', instructions: 'Contract pelvic floor muscles rapidly, hold for 2 seconds, then relax for 2 seconds.', tips: 'Do not contract abdominal or buttock muscles.' },
      { name: 'Endurance Holds', sets: 3, reps: '5 reps (8s hold)', restAfterSet: '45s', instructions: 'Perform a deep, sustained squeeze, holding for 8 seconds, followed by 10 seconds of rest.', tips: 'Breathing smoothly throughout.' },
      { name: 'Glute Bridges', sets: 3, reps: '12 reps', restAfterSet: '45s', instructions: 'Lift hips and squeeze pelvic floor at the top of the bridge.', tips: 'Squeeze pelvic muscles as you elevate.' }
    ]
  };

  const selectedExercises = defaultExercisesMap[goal] || defaultExercisesMap['Full Body'];
  const dailyCalories = goal === 'Weight Loss' ? 350 : goal === 'Six Pack' ? 250 : 380;
  const duration = level === 'Beginner' ? '20-30 mins' : level === 'Intermediate' ? '30-45 mins' : '45-60 mins';

  const planName = `FitMaster AI ${level} ${goal} Plan`;
  const weeklyFocus = `Focusing on progressive overload, conditioning, and strict form tailored to ${goal}.`;

  const days = [];
  const workoutDays = [1, 2, 3, 5, 6]; // Days 4 and 7 are rest days

  for (let d = 1; d <= 7; d++) {
    const isRest = !workoutDays.includes(d);
    
    // Scale sets/reps based on experience level
    const dayExercises = isRest ? [] : selectedExercises.map((ex, idx) => {
      let scaledSets = ex.sets;
      if (level === 'Intermediate') scaledSets += 1;
      if (level === 'Advanced') scaledSets += 2;
      return {
        ...ex,
        sets: scaledSets,
      };
    });

    days.push({
      dayNumber: d,
      title: isRest ? 'Active Recovery Day' : `Day ${d}: ${goal} Session`,
      focus: isRest ? 'Mind & Muscle Recovery' : goal,
      restDay: isRest,
      description: isRest 
        ? 'Rest and recovery are crucial for muscle fiber synthesis. Hydrate well, stretch, and perform light walking.' 
        : `Targeted workout to build stamina, strength, and enhance overall alignment with your goal of ${goal}.`,
      exercises: dayExercises
    });
  }

  return {
    planName,
    weeklyFocus,
    estimatedDailyDuration: duration,
    targetCaloriesPerDay: dailyCalories,
    days
  };
}

startServer();
