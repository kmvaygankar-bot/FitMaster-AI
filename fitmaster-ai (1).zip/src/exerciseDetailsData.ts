export interface ExerciseDetails {
  title: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  targetMuscles: string[];
  equipment: string;
  caloriesBurned: number; // kcal per minute
  duration: string;
  steps: string[];
  mistakes: string[];
  breathing: string;
  safetyTips: string[];
  beginnerTip: string;
  advancedTip: string;
  startImage: string;
  endImage: string;
}

// Map of generated custom illustrations with start/end postures
export const CUSTOM_ILLUSTRATIONS = {
  pushup: {
    start: '/src/assets/images/pushup_start_1784552210640.jpg',
    end: '/src/assets/images/pushup_end_1784552221084.jpg',
  },
  squat: {
    start: '/src/assets/images/squat_start_1784552230982.jpg',
    end: '/src/assets/images/squat_end_1784552242337.jpg',
  },
  plank: {
    start: '/src/assets/images/plank_start_1784552255325.jpg',
    end: '/src/assets/images/plank_end_1784552268015.jpg',
  },
  lunge: {
    start: '/src/assets/images/lunge_start_1784552281979.jpg',
    end: '/src/assets/images/lunge_end_1784552293667.jpg',
  },
  burpee: {
    start: '/src/assets/images/burpee_start_1784552309419.jpg',
    end: '/src/assets/images/burpee_end_1784552320208.jpg',
  }
};

export function getExerciseDetails(name: string): ExerciseDetails {
  const normalizedName = name.toLowerCase();

  // Helper to resolve images based on substrings
  let startImage = CUSTOM_ILLUSTRATIONS.squat.start;
  let endImage = CUSTOM_ILLUSTRATIONS.squat.end;

  if (normalizedName.includes('pushup') || normalizedName.includes('push-up')) {
    startImage = CUSTOM_ILLUSTRATIONS.pushup.start;
    endImage = CUSTOM_ILLUSTRATIONS.pushup.end;
  } else if (normalizedName.includes('squat')) {
    startImage = CUSTOM_ILLUSTRATIONS.squat.start;
    endImage = CUSTOM_ILLUSTRATIONS.squat.end;
  } else if (normalizedName.includes('plank')) {
    startImage = CUSTOM_ILLUSTRATIONS.plank.start;
    endImage = CUSTOM_ILLUSTRATIONS.plank.end;
  } else if (normalizedName.includes('lunge')) {
    startImage = CUSTOM_ILLUSTRATIONS.lunge.start;
    endImage = CUSTOM_ILLUSTRATIONS.lunge.end;
  } else if (normalizedName.includes('burpee')) {
    startImage = CUSTOM_ILLUSTRATIONS.burpee.start;
    endImage = CUSTOM_ILLUSTRATIONS.burpee.end;
  } else {
    // Fallback to pushup if arms-focused, squat if legs, plank if abs/other
    if (normalizedName.includes('bicep') || normalizedName.includes('tricep') || normalizedName.includes('arm')) {
      startImage = CUSTOM_ILLUSTRATIONS.pushup.start;
      endImage = CUSTOM_ILLUSTRATIONS.pushup.end;
    } else if (normalizedName.includes('stretch') || normalizedName.includes('yoga') || normalizedName.includes('dog') || normalizedName.includes('cobra')) {
      startImage = CUSTOM_ILLUSTRATIONS.plank.start;
      endImage = CUSTOM_ILLUSTRATIONS.plank.end;
    }
  }

  // Define Preset details for known exercises
  if (normalizedName.includes('pushup') || normalizedName.includes('push-up')) {
    const isDiamond = normalizedName.includes('diamond');
    const isDecline = normalizedName.includes('decline');
    const isIncline = normalizedName.includes('incline');

    return {
      title: name,
      difficulty: isDecline ? 'Advanced' : isDiamond ? 'Intermediate' : isIncline ? 'Beginner' : 'Beginner',
      targetMuscles: isDiamond ? ['Triceps Brachii', 'Pectoralis Major', 'Anterior Deltoids'] : ['Pectoralis Major', 'Anterior Deltoids', 'Triceps', 'Core'],
      equipment: isIncline ? 'Elevated Platform (Bench/Chair)' : 'Bodyweight / Floor Mat',
      caloriesBurned: isDecline ? 9 : isDiamond ? 8.5 : isIncline ? 6.5 : 8,
      duration: '3 Sets of 10-15 Repetitions',
      steps: [
        'Place hands on the floor (or elevated platform for incline) slightly wider than shoulder-width.',
        'Extend legs backward, balancing on your toes with feet together, creating a straight line from heels to head.',
        'Inhale and lower your entire body by bending elbows, keeping them tucked at a 45-degree angle to protect shoulders.',
        'Lower until your chest is approximately 2-3 inches (5-8 cm) off the ground.',
        'Exhale as you push through your palms to return to the starting position with full elbow extension.'
      ],
      mistakes: [
        'Saggy Hips / Lower Back Arch: Letting core relax causing back strain.',
        'Elbow Flaring: Flaring elbows out to 90 degrees, stressing the shoulder joints.',
        'Short Reps: Not going deep enough or failing to lock out at the top.'
      ],
      breathing: 'Inhale on the eccentric descent (lowering down), hold briefly at the bottom, and exhale forcefully on the concentric ascent (pushing up).',
      safetyTips: [
        'Maintain a tight, rigid abdomen throughout the movement to secure spinal alignment.',
        'Avoid locking joints aggressively at the top of the movement; maintain control.',
        'If wrists feel strained, use pushup handles or perform on fists to keep wrists neutral.'
      ],
      beginnerTip: 'Start with Incline Pushups against a wall or bench, or perform knee pushups to master the core brace before transitioning to full floor standard reps.',
      advancedTip: 'Perform Decline Pushups with feet elevated to overload upper pecs, or hold for 3 seconds at the bottom of standard pushups for isometric time-under-tension.',
      startImage,
      endImage
    };
  }

  if (normalizedName.includes('squat')) {
    const isBulgarian = normalizedName.includes('bulgarian') || normalizedName.includes('split');

    return {
      title: name,
      difficulty: isBulgarian ? 'Intermediate' : 'Beginner',
      targetMuscles: isBulgarian ? ['Quadriceps', 'Gluteus Maximus', 'Hamstrings', 'Adductors'] : ['Quadriceps Femoris', 'Gluteus Maximus', 'Hamstrings', 'Core'],
      equipment: isBulgarian ? 'Stable Chair or Gym Bench' : 'Bodyweight',
      caloriesBurned: isBulgarian ? 9.5 : 7.5,
      duration: '4 Sets of 12-15 Repetitions',
      steps: [
        isBulgarian 
          ? 'Stand about two feet in front of a bench. Extend one leg back and place the top of your foot flat on the bench surface.'
          : 'Stand upright with feet hip-to-shoulder width apart, toes pointed slightly outward (about 15 degrees).',
        isBulgarian
          ? 'Keep your hips square and hands on hips or together in front of your chest.'
          : 'Extend arms straight forward or cross them at your chest for auxiliary counterbalance.',
        'Inhale, hinge at your hips and bend your knees to lower your body, maintaining a tall and straight spine.',
        isBulgarian
          ? 'Descend until your front thigh is nearly parallel to the floor, ensuring the front knee does not cross forward past toes.'
          : 'Lower down until your hips drop below the line of your knees (break parallel) while keeping weight on heels.',
        'Exhale and drive forcefully through your heel to return to the tall starting upright posture.'
      ],
      mistakes: [
        'Knees Caving Inwards (Valgus Collapse): Putting immense pressure on the ACL/meniscus.',
        'Heels Lifting: Raising heels off the floor, placing excessive stress on patellar tendons.',
        'Rounding Lower Back (Butt Wink): Rounding spine at bottom of squat, exposing L4-L5 vertebrae.'
      ],
      breathing: 'Breathe in deeply as you initiate the descent, brace your core at the bottom, and exhale powerfully as you drive upward to a standing finish.',
      safetyTips: [
        'Keep your chest high and gaze forward; looking down encourages lower back rounding.',
        'Distribute weight evenly across the entire foot, focusing on heel and midfoot pressure.',
        'Ensure knees track in the same line as your toes throughout the entire rep range.'
      ],
      beginnerTip: 'Use a stable chair behind you for Box Squats. Sit down lightly to touch the seat, then stand up immediately to train the proper posterior hinge.',
      advancedTip: 'Perform Bulgarian Split Squats holding light dumbbells, or perform 1.5-rep squats (go all the way down, come halfway up, go down, then stand completely).',
      startImage,
      endImage
    };
  }

  if (normalizedName.includes('plank')) {
    return {
      title: name,
      difficulty: 'Beginner',
      targetMuscles: ['Rectus Abdominis (Six Pack)', 'Transversus Abdominis', 'Obliques', 'Serratus Anterior', 'Gluteals'],
      equipment: 'Comfortable Exercise Mat / Floor',
      caloriesBurned: 5.0,
      duration: '3 Sets of 45-60 Seconds Hold',
      steps: [
        'Kneel on your mat and place your forearms flat on the floor, elbows aligned directly under your shoulder joints.',
        'Extend both legs straight backward, feet hip-width apart, raising your body off the floor into a linear suspension.',
        'Engage your glutes, quadriceps, and abdominal wall intensely to create a rigid hollow body hold.',
        'Keep your neck neutral by looking down at the space between your hands (do not crane up or drop head).',
        'Hold this isometric position while maintaining continuous, controlled nasal breathing.'
      ],
      mistakes: [
        'Sinking/Sagging Hips: Letting gravity pull hips down, which compresses the lumbar spine.',
        'Piking Hips Upwards: Raising glutes too high in the air, removing the core load.',
        'Holding Breath: Forgetting to breathe, which spike blood pressure and restricts endurance.'
      ],
      breathing: 'Do not hold your breath. Implement steady, shallow diaphragmatic breathing (inhale through nose, exhale through pursed lips) while keeping core braced.',
      safetyTips: [
        'If you feel lower back pressure, immediately elevate your hips slightly or transition to a knee-plank.',
        'Avoid locking out your knees fully if hypermobile; maintain micro-flexion.',
        'Keep shoulders pushed away from ears to protect the scapular cuff.'
      ],
      beginnerTip: 'Hold the plank for shorter, high-quality intervals (e.g., 10-15 seconds) followed by 5 seconds rest, repeating 3-4 times to build muscle endurance.',
      advancedTip: 'Perform a Plank with Shoulder Taps from a high plank position, or raise one leg or arm off the ground to challenge rotational core stability.',
      startImage,
      endImage
    };
  }

  if (normalizedName.includes('lunge')) {
    return {
      title: name,
      difficulty: 'Beginner',
      targetMuscles: ['Quadriceps Femoris', 'Gluteus Maximus', 'Hamstrings', 'Soleus (Calves)', 'Core Stabilizers'],
      equipment: 'Bodyweight',
      caloriesBurned: 7.5,
      duration: '3 Sets of 12 Reps Per Leg',
      steps: [
        'Stand tall with feet hip-width apart, hands resting on your hips, chest open, shoulders relaxed.',
        'Inhale and take a controlled step forward (approx. 2.5 to 3 feet) with your right leg.',
        'Lower your hips straight down, bending both knees to 90-degree angles.',
        'Ensure your front knee is directly aligned over your front ankle and does not slide past toes; back knee should hover 1 inch off the floor.',
        'Exhale and push off your front heel forcefully to step back to the starting upright posture.'
      ],
      mistakes: [
        'Knee Overextension: Stepping too short, pushing the front knee far past the front toe line.',
        'Torso Lean: Leaning your torso forward, shifting all load onto the patellar joint.',
        'Tightrope Stepping: Stepping directly in front of the rear foot, losing lateral balance.'
      ],
      breathing: 'Inhale deeply as you step forward and descend. Exhale as you drive through the heel to stand back up.',
      safetyTips: [
        'Keep your hips square and shoulders aligned directly over your hips throughout.',
        'If balance is unstable, step slightly wider (hip-width) to expand your lateral base.',
        'Perform on a non-slippery surface to prevent knee hyperextension.'
      ],
      beginnerTip: 'Perform Static/Split lunges where your feet do not move between reps, simply lower and raise your hips vertically in place.',
      advancedTip: 'Perform Walking Lunges with a weighted rotation across the forward knee to heavily engage your obliques and proprioceptive stability.',
      startImage,
      endImage
    };
  }

  if (normalizedName.includes('burpee')) {
    return {
      title: name,
      difficulty: 'Advanced',
      targetMuscles: ['Quadriceps', 'Glutes', 'Pectorals', 'Core', 'Triceps', 'Cardiovascular System'],
      equipment: 'Bodyweight / Floor Mat',
      caloriesBurned: 12.5,
      duration: '3 Sets of 8-10 Reps',
      steps: [
        'Stand upright with feet shoulder-width apart, arms resting comfortably by your sides.',
        'Quickly bend your knees and hips, dropping into a deep squat, placing hands flat on the floor in front of you.',
        'Inhale and jump your feet backward explosively, landing in a perfect high plank position.',
        'Optionally perform a full floor chest-touch pushup, keeping a rigid core line.',
        'Exhale and jump your feet back forward next to your hands, rebounding back into the deep squat.',
        'Explode upward into a vertical jump, reaching your arms overhead, landing softly with soft knees.'
      ],
      mistakes: [
        'Floppy Core: Allowing your hips to sag when jumping back into the plank, straining the lumbar.',
        'Hard Landing: Landing with locked knees after the vertical jump, which shocks ankle and knee joints.',
        'Pacing Too Fast: Moving so quickly that posture breaks completely, risking strain.'
      ],
      breathing: 'Inhale as you squat down and jump back into the plank. Exhale on the pushup and jump forward. Inhale to prepare, and exhale powerfully on the jump.',
      safetyTips: [
        'Land with bent knees to absorb kinetic impact safely.',
        'If you feel dizzy due to high heart rate, slow down or march in place instead of jumping.',
        'Ensure wrists are fully warmed up before jumping your weight onto them.'
      ],
      beginnerTip: 'Perform a Half-Burpee (step back into a plank instead of jumping, and skip the final jump) to build physical conditioning and protect joints.',
      advancedTip: 'Perform a Burpee with a tuck jump at the end, or drop into a double push-up to exponentially multiply chest hypertrophy and endurance.',
      startImage,
      endImage
    };
  }

  // General Fallback details for other exercises (Crunches, Kegels, Stretch, etc.)
  let targetMuscles = ['Core Stabilizers', 'General Fullbody'];
  let difficulty: 'Beginner' | 'Intermediate' | 'Advanced' = 'Beginner';
  let equip = 'Bodyweight / Floor Mat';
  let cals = 6.0;

  if (normalizedName.includes('crunch') || normalizedName.includes('twist')) {
    targetMuscles = ['Rectus Abdominis', 'Obliques', 'Transversus Abdominis'];
    difficulty = normalizedName.includes('twist') ? 'Intermediate' : 'Beginner';
    cals = 5.5;
  } else if (normalizedName.includes('kegel') || normalizedName.includes('squeeze')) {
    targetMuscles = ['Pubococcygeus (PC) Muscle', 'Pelvic Floor Muscles', 'Deep Core'];
    difficulty = normalizedName.includes('endurance') ? 'Intermediate' : 'Beginner';
    cals = 2.0;
  } else if (normalizedName.includes('dog') || normalizedName.includes('stretch') || normalizedName.includes('cobra')) {
    targetMuscles = ['Hamstrings', 'Gastrocnemius', 'Spinal Erectors', 'Latissimus Dorsi'];
    difficulty = 'Beginner';
    cals = 3.5;
  } else if (normalizedName.includes('curl') || normalizedName.includes('bicep')) {
    targetMuscles = ['Biceps Brachii', 'Brachialis', 'Forearm Flexors'];
    difficulty = 'Beginner';
    cals = 6.0;
  }

  return {
    title: name,
    difficulty,
    targetMuscles,
    equipment: equip,
    caloriesBurned: cals,
    duration: '3 Sets of 10-15 Reps or 30s Hold',
    steps: [
      `Setup in the recommended starting position for ${name}, focusing on stabilizing your spine.`,
      'Initiate the primary motion with slow control, concentrating strictly on the active muscle group.',
      'Hold the contraction peak for 1-2 seconds to maximize motor-unit recruitment.',
      'Slightly resist gravity on the return, performing a slow eccentric release.',
      'Keep your muscles active and tense until the entire set is successfully completed.'
    ],
    mistakes: [
      'Using Momentum: Swinging your body rather than isolating the targeted muscle fibers.',
      'Poor Range of Motion: Cutting the movement short, which skips peak contraction.',
      'Improper Joint Alignment: Allowing knees or wrists to twist, causing unnecessary strain.'
    ],
    breathing: 'Exhale during the concentric phase (when contract/lifting), and inhale slowly during the eccentric phase (lowering/releasing).',
    safetyTips: [
      'Always warm up with light mobility movements before attempting challenging repetitions.',
      'Never push through sharp or sudden joint pain; halt immediately if felt.',
      'Keep your head and spine aligned to avoid neck strain.'
    ],
    beginnerTip: 'Focus strictly on learning the correct path of movement rather than adding speed or resistance.',
    advancedTip: 'Implement isometric pause holds at the absolute peak of the movement to recruit deeper, high-threshold muscle units.',
    startImage,
    endImage
  };
}
