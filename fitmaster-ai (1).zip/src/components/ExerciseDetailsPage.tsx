import React, { useState } from 'react';
import { 
  ChevronLeft, Flame, Clock, Dumbbell, AlertTriangle, Heart, Sparkles, 
  Wind, CheckCircle2, ShieldAlert, Award, Star, ArrowRight, Play, Lock, Check
} from 'lucide-react';
import { getExerciseDetails, ExerciseDetails } from '../exerciseDetailsData';

interface ExerciseDetailsPageProps {
  exerciseName: string;
  onBack: () => void;
  onStartExercise: () => void;
  isFavorite: boolean;
  onToggleFavorite: () => void;
  theme: 'light' | 'dark';
  isPremium: boolean;
  onUpgrade: () => void;
}

export const ExerciseDetailsPage: React.FC<ExerciseDetailsPageProps> = ({
  exerciseName,
  onBack,
  onStartExercise,
  isFavorite,
  onToggleFavorite,
  theme,
  isPremium,
  onUpgrade
}) => {
  const details = getExerciseDetails(exerciseName);
  const [activeSegment, setActiveSegment] = useState<'overview' | 'guide' | 'safety'>('overview');

  // Theme-dependent classes
  const isDark = theme === 'dark';
  const bgClass = isDark ? 'bg-[#0E0F12] text-neutral-100' : 'bg-[#F9FAFB] text-neutral-900';
  const cardBgClass = isDark ? 'bg-[#15161B] border-neutral-800/80' : 'bg-white border-neutral-200/80';
  const subTextClass = isDark ? 'text-neutral-400' : 'text-neutral-600';
  const dividerClass = isDark ? 'border-neutral-850' : 'border-neutral-200';

  // Difficulty badge styling
  const getDiffStyle = (diff: string) => {
    switch (diff) {
      case 'Beginner':
        return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
      case 'Intermediate':
        return 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';
      case 'Advanced':
        return 'bg-red-500/10 text-red-400 border border-red-500/20';
      default:
        return 'bg-neutral-500/10 text-neutral-400 border border-neutral-500/20';
    }
  };

  return (
    <div id="exercise-details-screen" className={`flex-1 flex flex-col min-h-screen ${bgClass} transition-colors duration-300 animate-fade-in pb-24`}>
      {/* Premium Gradient Top Background Decoration */}
      <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-emerald-500/10 to-transparent pointer-events-none" />

      {/* STICKY TOP NAVIGATION BAR */}
      <div className={`sticky top-0 z-20 backdrop-blur-md px-4 py-4 flex justify-between items-center border-b ${dividerClass} ${isDark ? 'bg-[#0E0F12]/80' : 'bg-[#F9FAFB]/80'}`}>
        <div className="flex items-center gap-3">
          <button 
            id="back-to-library-btn"
            onClick={onBack}
            className={`p-2.5 rounded-2xl border transition active:scale-95 ${
              isDark ? 'bg-neutral-900 border-neutral-800 hover:bg-neutral-800 text-neutral-300' : 'bg-white border-neutral-200 hover:bg-neutral-50 text-neutral-700'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <span className="text-[9px] font-black tracking-widest text-emerald-500 uppercase">KINETIC ANALYTICS</span>
            <h1 className="text-base font-black tracking-tight line-clamp-1">{details.title}</h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Heart Toggle */}
          <button 
            id="favorite-toggle-btn"
            onClick={onToggleFavorite}
            className={`p-2.5 rounded-2xl border transition active:scale-95 ${
              isFavorite 
                ? 'bg-red-500/10 border-red-500/30 text-red-500' 
                : isDark ? 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:bg-neutral-800' : 'bg-white border-neutral-200 text-neutral-500 hover:bg-neutral-50'
            }`}
            title="Toggle favorite status"
          >
            <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
          </button>

          {/* Premium Logo Pin */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[10px] font-black uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 fill-current animate-pulse" />
            <span>PREMIUM FORM</span>
          </div>
        </div>
      </div>

      {/* MAIN LAYOUT WRAPPER */}
      <div className="max-w-4xl mx-auto w-full px-4 mt-6 space-y-6 relative z-10 flex-1 flex flex-col">
        
        {/* HEADER HERO AREA */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex flex-wrap gap-2 items-center">
              <span className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest ${getDiffStyle(details.difficulty)}`}>
                {details.difficulty} DIFFICULTY
              </span>
              <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                isDark ? 'bg-neutral-900 text-neutral-400' : 'bg-neutral-100 text-neutral-600'
              }`}>
                {details.equipment}
              </span>
            </div>
            <h2 className="text-3xl font-black tracking-tight font-sans text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500">
              {details.title}
            </h2>
            <p className={`text-sm ${subTextClass} leading-relaxed max-w-2xl`}>
              Master your neuromuscular synchronization. Maintain strict eccentric control and pelvic posture lock to leverage anatomical load factors efficiently.
            </p>
          </div>
        </div>

        {/* METRICS INFOGRAPHIC GRID (BENTO STYLE) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {/* Target Muscles */}
          <div className={`p-4 rounded-3xl border ${cardBgClass} flex flex-col justify-between shadow-xs relative overflow-hidden group hover:border-emerald-500/30 transition`}>
            <div className="absolute top-[-20px] right-[-20px] w-20 h-20 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition" />
            <div className="flex items-center gap-2 text-neutral-400 mb-2">
              <Dumbbell className="w-4 h-4 text-emerald-500" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Target Muscles</span>
            </div>
            <div className="flex flex-wrap gap-1 mt-1">
              {details.targetMuscles.map((m, i) => (
                <span key={i} className={`text-[10px] font-semibold px-2 py-0.5 rounded ${
                  isDark ? 'bg-neutral-950/80 text-emerald-300' : 'bg-emerald-50 text-emerald-700'
                }`}>
                  {m}
                </span>
              ))}
            </div>
          </div>

          {/* Energy Cost */}
          <div className={`p-4 rounded-3xl border ${cardBgClass} flex flex-col justify-between shadow-xs relative overflow-hidden group hover:border-orange-500/30 transition`}>
            <div className="absolute top-[-20px] right-[-20px] w-20 h-20 bg-orange-500/5 rounded-full blur-xl group-hover:bg-orange-500/10 transition" />
            <div className="flex items-center gap-2 text-neutral-400 mb-2">
              <Flame className="w-4 h-4 text-orange-500" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Energy Cost</span>
            </div>
            <div>
              <span className="text-2xl font-black">{details.caloriesBurned}</span>
              <span className="text-xs font-bold text-neutral-500 ml-1">kcal / min</span>
            </div>
          </div>

          {/* Duration Protocol */}
          <div className={`p-4 rounded-3xl border ${cardBgClass} flex flex-col justify-between shadow-xs relative overflow-hidden group hover:border-blue-500/30 transition`}>
            <div className="absolute top-[-20px] right-[-20px] w-20 h-20 bg-blue-500/5 rounded-full blur-xl group-hover:bg-blue-500/10 transition" />
            <div className="flex items-center gap-2 text-neutral-400 mb-2">
              <Clock className="w-4 h-4 text-blue-500" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Protocol Unit</span>
            </div>
            <div>
              <p className="text-xs font-black tracking-tight line-clamp-2">{details.duration}</p>
            </div>
          </div>

          {/* Equipment Needs */}
          <div className={`p-4 rounded-3xl border ${cardBgClass} flex flex-col justify-between shadow-xs relative overflow-hidden group hover:border-purple-500/30 transition`}>
            <div className="absolute top-[-20px] right-[-20px] w-20 h-20 bg-purple-500/5 rounded-full blur-xl group-hover:bg-purple-500/10 transition" />
            <div className="flex items-center gap-2 text-neutral-400 mb-2">
              <Star className="w-4 h-4 text-purple-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Equipment</span>
            </div>
            <div>
              <span className="text-sm font-black line-clamp-1">{details.equipment}</span>
            </div>
          </div>
        </div>

        {/* VISUAL DEMONSTRATION SECTION */}
        <div className={`p-5 rounded-3xl border ${cardBgClass} space-y-4 shadow-md`}>
          <div className="flex justify-between items-center border-b pb-3 border-neutral-800/10">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-6 rounded bg-emerald-500" />
              <h3 className="text-base font-black tracking-tight uppercase">BIOMECHANICAL ALIGNMENT STAGES</h3>
            </div>
            <span className="text-[10px] font-semibold text-neutral-500 font-mono">STATIONARY TWO-PHASE DEMO</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Image 1: Start Position */}
            <div id="start-posture-card" className="space-y-2 relative group">
              <div className="relative aspect-square w-full rounded-2xl overflow-hidden border border-neutral-800/20 bg-neutral-950 shadow-inner flex items-center justify-center">
                <img 
                  src={details.startImage} 
                  alt={`${details.title} Start Position`}
                  className="w-full h-full object-cover transition duration-500 group-hover:scale-102"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                
                {/* Stage Badge */}
                <span className="absolute top-3 left-3 text-[9px] font-black text-white bg-emerald-500 px-2.5 py-1 rounded-full uppercase tracking-wider shadow">
                  STAGE 1: START POSITION
                </span>
                
                {/* Description bar */}
                <div className="absolute bottom-3 left-3 right-3 text-left">
                  <span className="block text-[8px] font-extrabold tracking-widest text-emerald-400 uppercase font-mono">NEURAL ANCHORING</span>
                  <p className="text-xs font-bold text-white leading-tight">Maintain spinal symmetry and establish load lock</p>
                </div>
              </div>
              <p className={`text-[11px] font-medium leading-relaxed ${subTextClass} px-1`}>
                Position your trunk correctly. Stand, sit, or lie down as illustrated to align your primary skeletal joints before engaging concentric drive.
              </p>
            </div>

            {/* Image 2: End Position */}
            <div id="end-posture-card" className="space-y-2 relative group">
              <div className="relative aspect-square w-full rounded-2xl overflow-hidden border border-neutral-800/20 bg-neutral-950 shadow-inner flex items-center justify-center">
                <img 
                  src={details.endImage} 
                  alt={`${details.title} End Position`}
                  className="w-full h-full object-cover transition duration-500 group-hover:scale-102"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                
                {/* Stage Badge */}
                <span className="absolute top-3 left-3 text-[9px] font-black text-white bg-blue-500 px-2.5 py-1 rounded-full uppercase tracking-wider shadow">
                  STAGE 2: END POSITION
                </span>
                
                {/* Description bar */}
                <div className="absolute bottom-3 left-3 right-3 text-left">
                  <span className="block text-[8px] font-extrabold tracking-widest text-blue-400 uppercase font-mono">PEAK INTEGRITY CONTRACTION</span>
                  <p className="text-xs font-bold text-white leading-tight">Complete full range-of-motion to recruit motor fibers</p>
                </div>
              </div>
              <p className={`text-[11px] font-medium leading-relaxed ${subTextClass} px-1`}>
                Drive through the full range of motion. Keep joint angles locked, and squeeze at the peak as displayed with motion vectors.
              </p>
            </div>
          </div>
        </div>

        {/* DETAILS SEGMENTED CONTROLS */}
        <div className="flex border-b border-neutral-800/20">
          {[
            { id: 'overview', label: 'Form & execution' },
            { id: 'guide', label: 'Instruction steps' },
            { id: 'safety', label: 'Safety & errors' }
          ].map(seg => (
            <button
              key={seg.id}
              onClick={() => {
                setActiveSegment(seg.id as any);
              }}
              className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition ${
                activeSegment === seg.id 
                  ? 'border-emerald-500 text-emerald-500 font-extrabold' 
                  : 'border-transparent text-neutral-500 hover:text-neutral-400'
              }`}
            >
              {seg.label}
            </button>
          ))}
        </div>

        {/* SEGMENT CONTENT BLOCKS */}
        {activeSegment === 'overview' && (
          <div className="space-y-4 animate-fade-in">
            {/* Step-by-Step Instructions */}
            <div className={`p-5 rounded-3xl border ${cardBgClass} space-y-3`}>
              <h4 className="text-sm font-black tracking-tight text-emerald-400 uppercase flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Anatomical Kinematics Protocol
              </h4>
              <div className="space-y-3 pt-1">
                {details.steps.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-3.5 text-xs">
                    <span className="w-5.5 h-5.5 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 font-mono border border-emerald-500/20 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className={`${subTextClass} font-medium leading-relaxed mt-0.5`}>{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Breathing Guide */}
            <div className={`p-5 rounded-3xl border bg-gradient-to-br ${
              isDark ? 'from-[#1A2536] to-[#121824] border-blue-900/30' : 'from-blue-50/50 to-indigo-50/30 border-blue-100'
            } flex gap-4 items-start shadow-sm`}>
              <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-400">
                <Wind className="w-5 h-5 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h5 className="text-xs font-black uppercase text-blue-400 tracking-wider">Dynamic Breathing Synchronicity</h5>
                <p className={`text-xs leading-relaxed font-medium ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                  {details.breathing}
                </p>
              </div>
            </div>
          </div>
        )}

        {activeSegment === 'guide' && (
          <div className="space-y-4 animate-fade-in">
            {/* Detailed Instructions list */}
            <div className={`p-5 rounded-3xl border ${cardBgClass} space-y-4`}>
              <h4 className="text-sm font-black tracking-tight uppercase">Step-by-step Execution Protocol</h4>
              <ol className="space-y-3 list-decimal list-inside pl-1 text-xs">
                {details.steps.map((step, idx) => (
                  <li key={idx} className={`${subTextClass} leading-relaxed font-medium`}>
                    <span className="ml-1 text-xs font-medium">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Common Mistakes Warning Block */}
            <div className={`p-5 rounded-3xl border bg-gradient-to-br ${
              isDark ? 'from-[#2B1B1C] to-[#1D1314] border-red-950/30' : 'from-red-50/50 to-orange-50/20 border-red-100'
            } space-y-3 shadow-xs`}>
              <h5 className="text-xs font-black uppercase text-red-400 tracking-wider flex items-center gap-2">
                <ShieldAlert className="w-4 h-4" />
                COMMON ALIGNMENT DEVILMENTS (MISTAKES)
              </h5>
              <div className="space-y-2">
                {details.mistakes.map((mis, i) => (
                  <div key={i} className="flex gap-2 items-start text-xs text-red-300">
                    <span className="text-red-500 font-bold shrink-0">•</span>
                    <p className={`text-xs font-medium ${isDark ? 'text-red-200/85' : 'text-red-900/80'}`}>{mis}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeSegment === 'safety' && (
          <div className="space-y-4 animate-fade-in">
            {/* Safety Tips Block */}
            <div className={`p-5 rounded-3xl border bg-gradient-to-br ${
              isDark ? 'from-[#2A2318] to-[#1A1610] border-amber-900/30' : 'from-amber-50/50 to-yellow-50/20 border-amber-100'
            } space-y-3 shadow-xs`}>
              <h5 className="text-xs font-black uppercase text-amber-400 tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                ANATOMICAL SAFETY PROTOCOLS
              </h5>
              <div className="space-y-2">
                {details.safetyTips.map((tip, i) => (
                  <div key={i} className="flex gap-2.5 items-start text-xs">
                    <span className="text-amber-500 font-bold shrink-0 font-mono">🛡️</span>
                    <p className={`text-xs font-semibold leading-relaxed ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>{tip}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Beginner and Advanced Tier Tips Block */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Beginner Tip */}
              <div className={`p-5 rounded-3xl border ${cardBgClass} space-y-2 relative overflow-hidden`}>
                <div className="absolute top-2 right-2 bg-emerald-500/15 text-emerald-400 text-[8px] font-black px-2 py-0.5 rounded uppercase font-mono">
                  Beginner Adaptive
                </div>
                <h5 className="text-xs font-black uppercase text-emerald-400 flex items-center gap-1.5">
                  <Award className="w-4 h-4" />
                  Starter Progression
                </h5>
                <p className={`text-xs leading-relaxed font-medium ${subTextClass}`}>
                  {details.beginnerTip}
                </p>
              </div>

              {/* Advanced Tip */}
              <div className={`p-5 rounded-3xl border bg-gradient-to-br from-amber-500/5 to-transparent border-amber-500/20 space-y-2 relative overflow-hidden`}>
                <div className="absolute top-2 right-2 bg-amber-500/15 text-amber-500 text-[8px] font-black px-2 py-0.5 rounded uppercase font-mono">
                  Advanced Overload
                </div>
                <h5 className="text-xs font-black uppercase text-amber-500 flex items-center gap-1.5">
                  <Star className="w-4 h-4" />
                  Kinetic Overload Mod
                </h5>
                <p className={`text-xs leading-relaxed font-semibold ${isDark ? 'text-neutral-300' : 'text-neutral-700'}`}>
                  {details.advancedTip}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* BOTTOM ACTIVE ACTION BLOCK */}
        <div className={`p-5 rounded-3xl border ${cardBgClass} shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4 mt-4 relative overflow-hidden`}>
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 to-transparent pointer-events-none" />
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[10px] bg-emerald-500/15 text-emerald-400 font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              READY TO EXECUTE?
            </span>
            <h4 className="text-sm font-black text-white">Engage direct audio coaching feedback now</h4>
            <p className={`text-xs ${subTextClass}`}>
              Launch this single exercise module immediately inside our kinetic audio sensor player.
            </p>
          </div>

          <button
            id="start-exercise-btn"
            onClick={onStartExercise}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-400 to-emerald-600 hover:from-emerald-500 hover:to-emerald-700 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition shadow-lg shadow-emerald-500/20"
          >
            <Play className="w-4 h-4 fill-current text-white" />
            <span>START REPS TRACKER</span>
          </button>
        </div>

      </div>
    </div>
  );
};
