import React, { useState, useEffect, useRef } from 'react';
import { 
  Dumbbell, Play, Plus, Trophy, Award, Calendar, ChevronRight, User, Settings, 
  Search, Heart, Smartphone, Moon, Sun, Flame, Droplet, Footprints, Target, 
  Activity, Volume2, Sparkles, AlertCircle, Share2, DollarSign, Crown, Lock, 
  Check, X, ChevronLeft, RefreshCw, CalendarDays
} from 'lucide-react';

import { getExerciseDetails } from './exerciseDetailsData';
import { ExerciseDetailsPage } from './components/ExerciseDetailsPage';
import { admobManager, ADMOB_IDS } from './admobConfig';

// ==========================================
// TYPES & CONTEXTS
// ==========================================
interface Exercise {
  name: string;
  sets: number;
  reps: string;
  restAfterSet: string;
  instructions: string;
  tips: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  image?: string;
}

interface WorkoutDay {
  dayNumber: number;
  title: string;
  focus: string;
  restDay: boolean;
  description: string;
  exercises: Exercise[];
}

interface WorkoutPlan {
  planName: string;
  weeklyFocus: string;
  estimatedDailyDuration: string;
  targetCaloriesPerDay: number;
  days: WorkoutDay[];
}

interface WeightLog {
  date: string;
  weight: number;
}

// ==========================================
// PRE-SET EXERCISE LIBRARY DATA
// ==========================================
const DEFAULT_LIBRARY_EXERCISES: Exercise[] = [
  { 
    name: 'Standard Pushups', 
    sets: 3, 
    reps: '12 reps', 
    restAfterSet: '45s', 
    category: 'Chest', 
    level: 'Beginner', 
    instructions: 'Place hands shoulder-width apart, lower body until chest nearly touches floor, keep body in flat plank.', 
    tips: 'Keep elbows tucked at a 45-degree angle.',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Incline Pushups', 
    sets: 3, 
    reps: '15 reps', 
    restAfterSet: '45s', 
    category: 'Chest', 
    level: 'Beginner', 
    instructions: 'Place hands on an elevated surface (chair/bench), lower chest to the edge, keep core engaged.', 
    tips: 'Great for targeting the lower chest.',
    image: 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Dumbbell Bench Press', 
    sets: 4, 
    reps: '10 reps', 
    restAfterSet: '60s', 
    category: 'Chest', 
    level: 'Intermediate', 
    instructions: 'Lie flat on a bench, press dumbbells upwards from chest height until arms are extended.', 
    tips: 'Squeeze your pecs at the top of the lift.',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Decline Pushups', 
    sets: 3, 
    reps: '10 reps', 
    restAfterSet: '60s', 
    category: 'Chest', 
    level: 'Advanced', 
    instructions: 'Place feet on an elevated surface, hands on floor, perform pushup with strict trunk alignment.', 
    tips: 'Targets upper chest fibers intensively.',
    image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Abdominal Crunches', 
    sets: 3, 
    reps: '20 reps', 
    restAfterSet: '30s', 
    category: 'Abs', 
    level: 'Beginner', 
    instructions: 'Lie on back with knees bent, curl shoulders towards hips using upper abdominal muscles.', 
    tips: 'Do not pull on your neck, exhale on the way up.',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Hanging Leg Raises', 
    sets: 3, 
    reps: '12 reps', 
    restAfterSet: '45s', 
    category: 'Abs', 
    level: 'Advanced', 
    instructions: 'Hang from pull-up bar, raise legs to 90 degrees keeping them straight, lower slowly.', 
    tips: 'Control the descent, avoid swinging.',
    image: 'https://images.unsplash.com/photo-1599058917212-d750089bc07e?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Plank Hold', 
    sets: 3, 
    reps: '60 seconds', 
    restAfterSet: '45s', 
    category: 'Abs', 
    level: 'Beginner', 
    instructions: 'Hold forearm plank with elbows directly under shoulders, squeeze core and glutes.', 
    tips: 'Keep your body in a straight line, do not let hips sag.',
    image: 'https://images.unsplash.com/photo-1566241477600-ac026ad43874?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Russian Twists', 
    sets: 3, 
    reps: '20 reps', 
    restAfterSet: '30s', 
    category: 'Abs', 
    level: 'Intermediate', 
    instructions: 'Sit with knees bent, feet slightly lifted, rotate torso and tap hands on the floor side-to-side.', 
    tips: 'Keep chest high and rotate with control.',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Air Squats', 
    sets: 4, 
    reps: '15 reps', 
    restAfterSet: '45s', 
    category: 'Legs', 
    level: 'Beginner', 
    instructions: 'Lower hips down and back as if sitting in a chair, keep chest up and weight on heels.', 
    tips: 'Drive through heels, squeeze glutes at top.',
    image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Bulgarian Split Squats', 
    sets: 3, 
    reps: '10 reps per leg', 
    restAfterSet: '45s', 
    category: 'Legs', 
    level: 'Intermediate', 
    instructions: 'Elevate one foot behind you on a bench, squat down on front leg until thigh is parallel to floor.', 
    tips: 'Keep front knee aligned with front foot.',
    image: 'https://images.unsplash.com/photo-1534258936925-c58bed479fcb?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Bodyweight Bicep Curls', 
    sets: 3, 
    reps: '12 reps', 
    restAfterSet: '45s', 
    category: 'Arms', 
    level: 'Beginner', 
    instructions: 'Underhand grip on a low bar or table edge, pull chest up toward the support, keeping core rigid.', 
    tips: 'Keep elbows still and squeeze biceps.',
    image: 'https://images.unsplash.com/photo-1581009146145-b5e1a40ed2db?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Diamond Pushups', 
    sets: 3, 
    reps: '10 reps', 
    restAfterSet: '45s', 
    category: 'Arms', 
    level: 'Intermediate', 
    instructions: 'Place hands close together on floor forming a diamond with index fingers and thumbs, do pushups.', 
    tips: 'Strong tricep and inner chest activation.',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Quick Pelvic Squeezes', 
    sets: 3, 
    reps: '10 reps (2s hold)', 
    restAfterSet: '30s', 
    category: 'Kegel', 
    level: 'Beginner', 
    instructions: 'Squeeze pelvic floor muscles quickly, hold for 2 seconds, release fully for 2 seconds.', 
    tips: 'Do not flex abs or glutes.',
    image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Endurance Kegel Hold', 
    sets: 3, 
    reps: '5 reps (8s hold)', 
    restAfterSet: '45s', 
    category: 'Kegel', 
    level: 'Intermediate', 
    instructions: 'Perform deep sustained pelvic contraction, hold for 8 full seconds, rest for 10 seconds.', 
    tips: 'Breathe smoothly, do not hold breath.',
    image: 'https://images.unsplash.com/photo-1599447421416-3414500d18a5?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Downward-Facing Dog', 
    sets: 3, 
    reps: '45 seconds', 
    restAfterSet: '15s', 
    category: 'Flexibility', 
    level: 'Beginner', 
    instructions: 'Form an inverted V with body, pushing heels down and letting chest sink towards thighs.', 
    tips: 'Lengthen spine, relax neck.',
    image: 'https://images.unsplash.com/photo-1603988363607-e1e4a66962c6?auto=format&fit=crop&w=400&q=80'
  },
  { 
    name: 'Cobra Stretch', 
    sets: 3, 
    reps: '30 seconds', 
    restAfterSet: '15s', 
    category: 'Flexibility', 
    level: 'Beginner', 
    instructions: 'Lie flat, press chest off floor keeping thighs grounded, look up slightly.', 
    tips: 'Keep shoulders away from ears.',
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=400&q=80'
  }
];

const MOTIVATIONAL_QUOTES = [
  { quote: "Your body can stand almost anything. It's your mind that you have to convince.", author: "Unknown" },
  { quote: "The only bad workout is the one that didn't happen.", author: "Unknown" },
  { quote: "Action is the foundational key to all success.", author: "Pablo Picasso" },
  { quote: "Today I will do what others won't, so tomorrow I can do what others can't.", author: "Jerry Rice" },
  { quote: "Suffer the pain of discipline or suffer the pain of regret.", author: "Jim Rohn" }
];

const CATEGORY_IMAGES: Record<string, string> = {
  'Chest': 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=400&q=80',
  'Abs': 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80',
  'Legs': 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?auto=format&fit=crop&w=400&q=80',
  'Arms': 'https://images.unsplash.com/photo-1581009146145-b5e1a40ed2db?auto=format&fit=crop&w=400&q=80',
  'Kegel': 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=400&q=80',
  'Flexibility': 'https://images.unsplash.com/photo-1603988363607-e1e4a66962c6?auto=format&fit=crop&w=400&q=80'
};

const DEFAULT_CATEGORY_IMAGE = 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=400&q=80';

export default function App() {
  // ==========================================
  // APP LIFECYCLE & STATE MANAGERS
  // ==========================================
  const [currentScreen, setCurrentScreen] = useState<'splash' | 'welcome' | 'onboarding' | 'home' | 'workout_player' | 'kegel_player' | 'workout_complete' | 'exercise_details'>('splash');
  const [activeTab, setActiveTab] = useState<'home' | 'workouts' | 'library' | 'progress' | 'profile'>('home');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [isPremium, setIsPremium] = useState<boolean>(false);
  const [showPremiumModal, setShowPremiumModal] = useState<boolean>(false);

  // Selected Detail Exercise state
  const [selectedDetailExercise, setSelectedDetailExercise] = useState<Exercise | null>(null);
  const [previousScreenBeforeDetails, setPreviousScreenBeforeDetails] = useState<'home' | 'workout_player'>('home');

  // AdMob Simulation States
  const [showAdInterstitial, setShowAdInterstitial] = useState<boolean>(false);
  const [interstitialAdData, setInterstitialAdData] = useState({ title: '', desc: '', image: '', actionUrl: '' });
  const [adCountdown, setAdCountdown] = useState<number>(4);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [admobVisible, setAdmobVisible] = useState<boolean>(true);
  const [activeAdIdx, setActiveAdIdx] = useState<number>(0);
  const [lastAdTime, setLastAdTime] = useState<number>(Date.now() - 40000);

  // Mock Heart Rate Monitor States
  const [heartRate, setHeartRate] = useState<number>(72);
  const [hrIntensity, setHrIntensity] = useState<'low' | 'moderate' | 'high' | 'peak'>('low');

  const MOCK_ADS = [
    { title: "🏋️ Nike Run Club: Plan Your Next Run", desc: "Track distance, pace, and elevate your fitness routine.", url: "https://www.nike.com", btnText: "Install" },
    { title: "🥛 MyProtein: Flat 40% OFF Today", desc: "Premium Whey isolate, Creatine, and high quality gym nutrition.", url: "https://www.myprotein.com", btnText: "Shop Now" },
    { title: "👟 Puma Nitro: Run on Clouds", desc: "Explore the new Nitro foam-injected running line. 20% discount.", url: "https://www.puma.com", btnText: "Explore" },
    { title: "⌚ Garmin Forerunner 965", desc: "The ultimate triathlete smart-watch with offline maps.", url: "https://www.garmin.com", btnText: "Buy Now" },
    { title: "🧘 Headspace: Meditate & Sleep", desc: "Join 70+ million members finding daily calm and focused minds.", url: "https://www.headspace.com", btnText: "Try Free" },
  ];

  // Rotate banner ads every 12 seconds
  useEffect(() => {
    const adInterval = setInterval(() => {
      setActiveAdIdx(prev => (prev + 1) % MOCK_ADS.length);
    }, 12000);
    return () => clearInterval(adInterval);
  }, []);

  // Interstitial countdown
  useEffect(() => {
    let timer: any;
    if (showAdInterstitial && adCountdown > 0) {
      timer = setInterval(() => {
        setAdCountdown(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [showAdInterstitial, adCountdown]);

  const triggerInterstitialIfFree = (onCloseAction: () => void, force: boolean = false) => {
    if (isPremium) {
      onCloseAction();
      return;
    }
    const now = Date.now();
    // If not forced and not enough time has passed, skip showing the ad
    if (!force && now - lastAdTime < 60000) {
      onCloseAction();
      return;
    }
    setLastAdTime(now);

    // Handle no-internet and ad-load failures gracefully
    if (admobManager.isDeviceOffline()) {
      console.warn(`[AdMob] Interstitial Ad Unit [${ADMOB_IDS.INTERSTITIAL_UNIT_ID}] skipped: Device is Offline.`);
      onCloseAction();
      return;
    }

    const showAd = (adData: any) => {
      setInterstitialAdData(adData);
      setAdCountdown(4);
      setPendingAction(() => () => {
        onCloseAction();
        admobManager.onInterstitialClosed();
      });
      setShowAdInterstitial(true);
    };

    if (admobManager.isInterstitialReady()) {
      const ad = admobManager.getInterstitialAd();
      if (ad) {
        showAd(ad);
      } else {
        onCloseAction();
      }
    } else {
      // Load on the fly before showing if not preloaded (with graceful failure fallback)
      console.log(`[AdMob] Interstitial not ready. Loading on-the-fly for unit: ${ADMOB_IDS.INTERSTITIAL_UNIT_ID}...`);
      admobManager.preloadNextInterstitial().then(success => {
        if (success) {
          const ad = admobManager.getInterstitialAd();
          if (ad) {
            showAd(ad);
          } else {
            onCloseAction();
          }
        } else {
          console.warn("[AdMob] Failed to load interstitial on-the-fly. Continuing gracefully.");
          onCloseAction();
        }
      }).catch(err => {
        console.error("[AdMob] Error loading interstitial on-the-fly:", err);
        onCloseAction();
      });
    }
  };
  
  // Onboarding Profile State
  const [age, setAge] = useState<string>('24');
  const [gender, setGender] = useState<string>('Male');
  const [height, setHeight] = useState<string>('175');
  const [weight, setWeight] = useState<string>('70');
  const [goal, setGoal] = useState<string>('Full Body');
  const [equipment, setEquipment] = useState<string>('Bodyweight Only');
  const [experience, setExperience] = useState<string>('Beginner');

  // User Logs & Progression Stats
  const [streak, setStreak] = useState<number>(3);
  const [caloriesBurned, setCaloriesBurned] = useState<number>(180);
  const [waterIntake, setWaterIntake] = useState<number>(750); // ml
  const [stepsCount, setStepsCount] = useState<number>(3420);
  const [isSimulatingSteps, setIsSimulatingSteps] = useState<boolean>(false);
  
  // Custom Dynamic Workout Plan
  const [workoutPlan, setWorkoutPlan] = useState<WorkoutPlan | null>(null);
  const [isGeneratingPlan, setIsGeneratingPlan] = useState<boolean>(false);
  
  // Lists
  const [weightLogs, setWeightLogs] = useState<WeightLog[]>([
    { date: 'Jul 10', weight: 72.5 },
    { date: 'Jul 12', weight: 72.0 },
    { date: 'Jul 14', weight: 71.4 },
    { date: 'Jul 16', weight: 70.8 },
    { date: 'Jul 18', weight: 70.2 },
    { date: 'Jul 20', weight: 70.0 }
  ]);
  const [newWeightInput, setNewWeightInput] = useState<string>('');
  
  const [bodyMeasurements, setBodyMeasurements] = useState({
    chest: 96,
    waist: 82,
    hips: 94,
    arms: 34
  });

  const [favorites, setFavorites] = useState<string[]>(['Standard Pushups', 'Plank Hold']);
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>(['streak_3', 'water_cup']);
  const [activeQuote, setActiveQuote] = useState({ quote: "The only bad workout is the one that didn't happen.", author: "Unknown" });
  
  // Search & Filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // 30-Day Six-Pack Challenge state
  const [sixPackChallengeDay, setSixPackChallengeDay] = useState<number>(5);
  const [coreStrengthScore, setCoreStrengthScore] = useState<number>(68);

  // Active Workout Player Engine State
  const [playerWorkoutTitle, setPlayerWorkoutTitle] = useState<string>('');
  const [playerExercises, setPlayerExercises] = useState<Exercise[]>([]);
  const [activeExerciseIdx, setActiveExerciseIdx] = useState<number>(0);
  const [activeSetIdx, setActiveSetIdx] = useState<number>(0);
  const [playerState, setPlayerState] = useState<'ready' | 'playing' | 'rest' | 'paused'>('ready');
  const [playerTimer, setPlayerTimer] = useState<number>(10);
  const [totalWorkoutDuration, setTotalWorkoutDuration] = useState<number>(0); // in seconds
  const [caloriesAccrued, setCaloriesAccrued] = useState<number>(0);

  // Kegel Rhythmic State
  const [kegelMode, setKegelMode] = useState<'squeeze' | 'relax'>('relax');
  const [kegelRepsRemaining, setKegelRepsRemaining] = useState<number>(10);

  // Timers and references
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const durationRef = useRef<NodeJS.Timeout | null>(null);

  // Mock Heart Rate Monitor Simulation Game Loop
  useEffect(() => {
    let interval: any = null;
    if (currentScreen === 'workout_player') {
      interval = setInterval(() => {
        setHeartRate(prev => {
          let nextHr = prev;
          if (playerState === 'playing') {
            // Gradually climb up to realistic training range: 130-170
            if (prev < 130) {
              nextHr = prev + Math.floor(Math.random() * 4) + 1;
            } else if (prev > 170) {
              nextHr = prev - Math.floor(Math.random() * 3) - 1;
            } else {
              // Fluctuate
              nextHr = prev + (Math.random() > 0.48 ? Math.floor(Math.random() * 3) : -Math.floor(Math.random() * 3));
            }
          } else if (playerState === 'rest') {
            // Gradually decline down to rest recovery range: 85-115
            if (prev > 115) {
              nextHr = prev - Math.floor(Math.random() * 3) - 1;
            } else if (prev < 85) {
              nextHr = prev + Math.floor(Math.random() * 2) + 1;
            } else {
              // Fluctuate
              nextHr = prev + (Math.random() > 0.52 ? Math.floor(Math.random() * 2) : -Math.floor(Math.random() * 2));
            }
          } else {
            // 'ready', 'paused' or other inactive player state: return to resting: 65-80
            if (prev > 80) {
              nextHr = prev - Math.floor(Math.random() * 2) - 1;
            } else if (prev < 65) {
              nextHr = prev + Math.floor(Math.random() * 2) + 1;
            } else {
              nextHr = prev + (Math.random() > 0.5 ? 1 : -1);
            }
          }
          // Bounds safety
          return Math.max(60, Math.min(185, nextHr));
        });
      }, 1000);
    } else {
      // Settle back to resting heart rate when not in player
      setHeartRate(72);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [currentScreen, playerState]);

  // Sync intensity category with heartRate updates
  useEffect(() => {
    if (heartRate < 100) {
      setHrIntensity('low');
    } else if (heartRate >= 100 && heartRate <= 130) {
      setHrIntensity('moderate');
    } else if (heartRate > 130 && heartRate <= 155) {
      setHrIntensity('high');
    } else {
      setHrIntensity('peak');
    }
  }, [heartRate]);

  // ==========================================
  // INITIALIZERS & STORAGE PERSISTENCE
  // ==========================================
  useEffect(() => {
    // Initialize Google AdMob production configurations
    admobManager.initialize();

    // Splash Timeout
    const splashTimer = setTimeout(() => {
      // Check if user has generated plan, if not, show welcome/onboarding
      const savedPlan = localStorage.getItem('fitmaster_plan');
      if (savedPlan) {
        setWorkoutPlan(JSON.parse(savedPlan));
        setCurrentScreen('home');
      } else {
        setCurrentScreen('welcome');
      }
    }, 2400);

    // Fetch Motivation Quote
    fetch('/api/motivation')
      .then(r => r.json())
      .then(data => {
        if (data && data.quote) setActiveQuote(data);
      })
      .catch(() => {});

    // Load static logs if exists
    const storedHistory = localStorage.getItem('fitmaster_history');
    if (storedHistory) {
      // Could reconstruct stats
    }

    return () => {
      clearTimeout(splashTimer);
      if (timerRef.current) clearInterval(timerRef.current);
      if (durationRef.current) clearInterval(durationRef.current);
    };
  }, []);

  // Sync Pedometer simulation
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isSimulatingSteps) {
      interval = setInterval(() => {
        setStepsCount(prev => prev + Math.floor(Math.random() * 5) + 2);
        if (Math.random() > 0.8) {
          setCaloriesBurned(prev => prev + 1);
        }
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSimulatingSteps]);

  // Voice Coach Helper using Web Speech API
  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Synthesizer beep
  const playBeep = (frequency = 800, duration = 150) => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = frequency;
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.005, ctx.currentTime + duration / 1000);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration / 1000);
    } catch (e) {
      console.log('Audio Context muted or not allowed', e);
    }
  };

  // Create Workout Plan via server-side Gemini or local fallback
  const handleGeneratePlan = async () => {
    setIsGeneratingPlan(true);
    speak("Analyzing profile and designing your intelligent 7 day workout cycle.");
    
    try {
      const response = await fetch('/api/workout-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          age, gender, height, weight, goal, equipment, experience
        })
      });

      if (!response.ok) throw new Error('API failed');
      const data = await response.json();
      
      setWorkoutPlan(data);
      localStorage.setItem('fitmaster_plan', JSON.stringify(data));
      setCurrentScreen('home');
      setActiveTab('home');
      speak("Your dynamic workout plan is built! Let's conquer your fitness goals.");
    } catch (err) {
      console.error(err);
      // Emergency plan builder fallback (handled on server, but in case of catastrophic network offline)
      speak("Connected safely offline. Setting up optimized conditioning program.");
      setCurrentScreen('home');
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  // Start Workout Player
  const launchWorkout = (title: string, exercises: Exercise[]) => {
    setPlayerWorkoutTitle(title);
    setPlayerExercises(exercises);
    setActiveExerciseIdx(0);
    setActiveSetIdx(0);
    setCaloriesAccrued(0);
    setTotalWorkoutDuration(0);
    
    const firstEx = exercises[0];
    if (firstEx) {
      const seconds = firstEx.reps.includes('second') 
        ? parseInt(firstEx.reps) || 30 
        : 15; // default 15s timer if reps is standard
      setPlayerTimer(seconds);
    }
    
    setPlayerState('ready');
    setCurrentScreen('workout_player');
    
    speak(`Get ready for ${title}. First up is ${firstEx?.name || 'Warm Up'}.`);
  };

  // Start Kegel Trainer
  const launchKegelTrainer = (title: string) => {
    setPlayerWorkoutTitle(title);
    setKegelRepsRemaining(10);
    setKegelMode('relax');
    setPlayerTimer(3); // 3s starting rest
    setTotalWorkoutDuration(0);
    setCaloriesAccrued(0);
    setPlayerState('ready');
    setCurrentScreen('kegel_player');
    speak("Get ready for Pelvic Floor training. Standard contraction cycles about to begin.");
  };

  // Workout Player Game Loop
  useEffect(() => {
    if (currentScreen === 'workout_player' && (playerState === 'playing' || playerState === 'rest')) {
      timerRef.current = setInterval(() => {
        setPlayerTimer(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            if (playerState === 'playing') {
              handleExerciseStepComplete();
            } else {
              skipRest();
            }
            return 0;
          }
          if (playerState === 'playing' && (prev === 4 || prev === 3 || prev === 2)) {
            playBeep(600, 80);
          }
          return prev - 1;
        });
      }, 1000);

      // Track elapsed global workout time
      durationRef.current = setInterval(() => {
        setTotalWorkoutDuration(d => d + 1);
        setCaloriesAccrued(c => c + 0.35); // standard burn estimation
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (durationRef.current) clearInterval(durationRef.current);
    };
  }, [currentScreen, playerState, activeExerciseIdx, activeSetIdx]);

  // Kegel Trainer loop
  useEffect(() => {
    if (currentScreen === 'kegel_player' && playerState === 'playing') {
      timerRef.current = setInterval(() => {
        setPlayerTimer(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            // Toggle squeeze / relax
            if (kegelMode === 'relax') {
              setKegelMode('squeeze');
              speak("Squeeze! Pull pelvic muscles up and hold.");
              playBeep(900, 200);
              return 6; // 6 seconds hold
            } else {
              setKegelMode('relax');
              setKegelRepsRemaining(r => {
                const repsCompleted = 10 - r + 1;
                if (!isPremium && repsCompleted >= 3) {
                  setPlayerState('paused');
                  setShowPremiumModal(true);
                  speak("Pelvic floor training trial complete! Under our 30% free-tier program, you have completed 3 squeeze cycles. Upgrade to Pro to finish the entire workout!");
                  return r;
                }
                if (r <= 1) {
                  handleKegelWorkoutComplete();
                  return 0;
                }
                speak("Relax. Breathe deeply.");
                playBeep(500, 150);
                return r - 1;
              });
              return 6; // 6 seconds relax
            }
          }
          return prev - 1;
        });
      }, 1000);

      durationRef.current = setInterval(() => {
        setTotalWorkoutDuration(d => d + 1);
        setCaloriesAccrued(c => c + 0.1); // lower intensity kegel calorie burn
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (durationRef.current) clearInterval(durationRef.current);
    };
  }, [currentScreen, playerState, kegelMode, kegelRepsRemaining]);

  // Finish Single Set or Exercise Step
  const handleExerciseStepComplete = () => {
    playBeep(1200, 300);
    const curEx = playerExercises[activeExerciseIdx];
    
    if (activeSetIdx + 1 < curEx.sets) {
      // Transition to REST between sets
      setPlayerState('rest');
      const restSecs = parseInt(curEx.restAfterSet) || 30;
      setPlayerTimer(restSecs);
      speak(`Set ${activeSetIdx + 1} complete. Rest for ${restSecs} seconds.`);
    } else {
      // Completed all sets for this exercise. Move to next exercise
      if (activeExerciseIdx + 1 < playerExercises.length) {
        const freeLimit = Math.max(1, Math.ceil(playerExercises.length * 0.3));
        if (!isPremium && activeExerciseIdx + 1 >= freeLimit) {
          setPlayerState('paused');
          setShowPremiumModal(true);
          speak(`Free tier limit reached. Under our 30% free program, the first ${freeLimit} exercises are unlocked. Upgrade to Pro to complete the remaining ${playerExercises.length - freeLimit} exercises!`);
          return;
        }
        setPlayerState('rest');
        setPlayerTimer(30); // standard 30s rest between unique exercises
        speak(`Excellent. You completed all sets of ${curEx.name}. Take a 30 second rest. Up next: ${playerExercises[activeExerciseIdx + 1].name}`);
      } else {
        // Workout Finished completely!
        handleFullWorkoutComplete();
      }
    }
  };

  // Proceed from Rest state
  const skipRest = () => {
    if (playerState !== 'rest') return;
    
    const proceed = () => {
      setPlayerTimer(0);
      const curEx = playerExercises[activeExerciseIdx];
      if (activeSetIdx + 1 < curEx.sets) {
        setActiveSetIdx(prev => prev + 1);
        const isTimerEx = curEx.reps.includes('second');
        setPlayerTimer(isTimerEx ? parseInt(curEx.reps) || 30 : 15);
        setPlayerState('ready');
        speak(`Get ready for Set ${activeSetIdx + 2} of ${curEx.name}.`);
      } else {
        setActiveExerciseIdx(prev => prev + 1);
        setActiveSetIdx(0);
        const nextEx = playerExercises[activeExerciseIdx + 1];
        if (nextEx) {
          const isTimerEx = nextEx.reps.includes('second');
          setPlayerTimer(isTimerEx ? parseInt(nextEx.reps) || 30 : 15);
          setPlayerState('ready');
          speak(`Get ready for ${nextEx.name}.`);
        }
      }
    };

    triggerInterstitialIfFree(proceed);
  };

  // Complete Workout completely
  const handleFullWorkoutComplete = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (durationRef.current) clearInterval(durationRef.current);
    
    // Add completed stats to daily aggregates
    const finalCals = Math.round(caloriesAccrued || 150);
    setCaloriesBurned(prev => prev + finalCals);
    setStreak(prev => prev === 0 ? 1 : prev + 1);
    
    // Unlocking achievement badges
    const newBadges = [...unlockedBadges];
    if (!newBadges.includes('workout_one')) {
      newBadges.push('workout_one');
    }
    if (streak + 1 >= 4 && !newBadges.includes('streak_4')) {
      newBadges.push('streak_4');
    }
    setUnlockedBadges(newBadges);

    speak(`Congratulations! You crushed today's workout. You burned ${finalCals} calories. Keep it up!`);
    
    triggerInterstitialIfFree(() => {
      setCurrentScreen('workout_complete');
    });
  };

  const handleKegelWorkoutComplete = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (durationRef.current) clearInterval(durationRef.current);
    
    setCaloriesBurned(prev => prev + Math.round(caloriesAccrued || 20));
    const newBadges = [...unlockedBadges];
    if (!newBadges.includes('kegel_master')) {
      newBadges.push('kegel_master');
    }
    setUnlockedBadges(newBadges);
    setCoreStrengthScore(prev => Math.min(100, prev + 2));
    
    speak("Kegel Session complete! Incredible pelvic control. Your core-strength index is climbing.");
    
    triggerInterstitialIfFree(() => {
      setCurrentScreen('workout_complete');
    });
  };

  // Water Tracker Sizing & Sensation
  const addWater = (amount: number) => {
    setWaterIntake(prev => {
      const next = prev + amount;
      if (next >= 2000 && !unlockedBadges.includes('water_champion')) {
        setUnlockedBadges(b => [...b, 'water_champion']);
        speak("Splendid! Hydration goals crushed. You unlocked the Water Champion badge!");
      }
      return next;
    });
    playBeep(1000, 100);
  };

  const toggleFavorite = (name: string) => {
    if (favorites.includes(name)) {
      setFavorites(favorites.filter(x => x !== name));
    } else {
      setFavorites([...favorites, name]);
      playBeep(1100, 80);
    }
  };

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(newWeightInput);
    if (!isNaN(val) && val > 30 && val < 250) {
      const today = new Date();
      const dateStr = today.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      setWeightLogs([...weightLogs, { date: dateStr, weight: val }]);
      setWeight(val.toString());
      setNewWeightInput('');
      playBeep(800, 150);
      speak(`Logged ${val} kilograms. Keep tracking your trajectory.`);
    }
  };

  // Toggle Theme helper
  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
    playBeep(700, 100);
  };

  // BMI Calculator helper
  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100;
    if (w > 0 && h > 0) {
      return (w / (h * h)).toFixed(1);
    }
    return '0.0';
  };

  const bmiValue = parseFloat(calculateBMI());
  const getBMICategory = (val: number) => {
    if (val < 18.5) return { text: 'Underweight', color: 'text-amber-400' };
    if (val < 25) return { text: 'Healthy Weight', color: 'text-emerald-500' };
    if (val < 30) return { text: 'Overweight', color: 'text-orange-400' };
    return { text: 'Obese', color: 'text-red-500' };
  };
  const bmiCat = getBMICategory(bmiValue);

  // SVG Weight Tracker Plotter (Custom Responsive Line Chart)
  const renderWeightGraph = () => {
    if (weightLogs.length === 0) return null;
    const padding = 30;
    const width = 340;
    const height = 140;

    const weights = weightLogs.map(l => l.weight);
    const maxW = Math.max(...weights) + 1;
    const minW = Math.min(...weights) - 1;
    const diffW = maxW - minW || 1;

    const points = weightLogs.map((l, i) => {
      const x = padding + (i / (weightLogs.length - 1)) * (width - padding * 2);
      const y = height - padding - ((l.weight - minW) / diffW) * (height - padding * 2);
      return { x, y, ...l };
    });

    const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

    return (
      <svg className="w-full h-36 mt-2 overflow-visible" viewBox={`0 0 ${width} ${height}`}>
        {/* Grid lines */}
        <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#3e414c" strokeOpacity={0.2} strokeDasharray="3 3" />
        <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="#3e414c" strokeOpacity={0.2} strokeDasharray="3 3" />
        <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#3e414c" strokeOpacity={0.3} />

        {/* Dynamic Line */}
        <path d={pathData} fill="none" stroke="#A8C7FA" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />

        {/* Data points & labels */}
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r="4" fill="#34C759" stroke="#fff" strokeWidth="1.5" className="cursor-pointer" />
            <text x={p.x} y={p.y - 10} fontSize="9" textAnchor="middle" fill="#C4C7C5" className="font-semibold">{p.weight}kg</text>
            <text x={p.x} y={height - 12} fontSize="9" textAnchor="middle" fill="#8E918F">{p.date}</text>
          </g>
        ))}
      </svg>
    );
  };

  // Filter Exercises in Library
  const filteredExercises = DEFAULT_LIBRARY_EXERCISES.filter(ex => {
    const matchesSearch = ex.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          ex.instructions.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'All' || ex.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  // Today's Workouts setup
  const getTodayWorkout = (): { title: string; exercises: Exercise[]; duration: string; calories: number } => {
    const defaultExs = DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Chest' || e.category === 'Abs');
    if (!workoutPlan) {
      return {
        title: "Introduction to Conditioning",
        exercises: defaultExs,
        duration: "15-20 mins",
        calories: 140
      };
    }
    // Get corresponding day cycle
    const dayIndex = (streak) % 7;
    const activeDay = workoutPlan.days[dayIndex] || workoutPlan.days[0];
    
    // If it's a rest day, give a restorative stretch session
    if (activeDay.restDay) {
      return {
        title: "Active Restoration & Core Alignment",
        exercises: DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Flexibility' || e.category === 'Kegel'),
        duration: "15 mins",
        calories: 60
      };
    }

    return {
      title: activeDay.title,
      exercises: activeDay.exercises && activeDay.exercises.length > 0 ? activeDay.exercises : defaultExs,
      duration: workoutPlan.estimatedDailyDuration,
      calories: workoutPlan.targetCaloriesPerDay
    };
  };

  const todayWorkout = getTodayWorkout();

  const renderExerciseVisual = (category: string) => {
    switch (category) {
      case 'Legs':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-16 h-16 text-emerald-400 overflow-visible" viewBox="0 0 60 60">
              <circle cx="30" cy="30" r="28" fill="none" stroke="#10B981" strokeWidth="1" strokeDasharray="2 3" strokeOpacity="0.2" />
              <g className="animate-squat origin-bottom">
                {/* Spine & Head */}
                <line x1="30" y1="14" x2="30" y2="30" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                <circle cx="30" cy="8" r="4.5" fill="#34C759" />
                {/* Arm / Balance line */}
                <line x1="30" y1="16" x2="14" y2="16" stroke="#059669" strokeWidth="2.5" strokeLinecap="round" />
                {/* Hip to Knee (Thigh / Quad Heatmap) */}
                <line x1="30" y1="30" x2="42" y2="38" stroke="#EF4444" strokeWidth="4.5" strokeLinecap="round" className="opacity-80 animate-pulse" /> {/* Heatmap glow */}
                <line x1="30" y1="30" x2="42" y2="38" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                {/* Knee to Ankle (Calf) */}
                <line x1="42" y1="38" x2="30" y2="52" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
                {/* Joint Trackers */}
                <circle cx="30" cy="30" r="2.5" fill="#34C759" /> {/* Hip */}
                <circle cx="42" cy="38" r="2.5" fill="#10B981" /> {/* Knee */}
                <circle cx="30" cy="52" r="2.5" fill="#047857" /> {/* Ankle */}
                {/* Joint Angle Overlay Text */}
                <text x="45" y="34" fontSize="6" className="font-mono font-bold fill-emerald-400">95°</text>
              </g>
              <line x1="10" y1="52" x2="50" y2="52" stroke="#374151" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-emerald-400 bg-[#0F1014]/90 px-1.5 py-0.5 rounded border border-emerald-800/30 uppercase tracking-widest">
              BIOMETRIC SQUAT MATRIX
            </div>
          </div>
        );
      case 'Chest':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-18 h-14 text-emerald-400 overflow-visible" viewBox="0 0 70 50">
              {/* Floor plane */}
              <line x1="5" y1="42" x2="65" y2="42" stroke="#374151" strokeWidth="1.5" strokeDasharray="1 2" />
              <line x1="15" y1="42" x2="55" y2="42" stroke="#4B5563" strokeWidth="1.5" />
              
              <g className="animate-pushup origin-bottom">
                {/* Head */}
                <circle cx="16" cy="18" r="4.5" fill="#34C759" />
                {/* Spine alignment vector (Neck to Hip) */}
                <line x1="16" y1="20" x2="52" y2="30" stroke="#10B981" strokeWidth="3.5" strokeLinecap="round" />
                {/* Leg Vector (Hip to Feet) */}
                <line x1="52" y1="30" x2="62" y2="42" stroke="#059669" strokeWidth="3" strokeLinecap="round" />
                {/* Shoulder joint */}
                <circle cx="22" cy="21" r="2" fill="#34C759" />
                {/* Arm bending mechanism (Shoulder to Elbow, Elbow to Hand) */}
                <line x1="22" y1="21" x2="28" y2="34" stroke="#EF4444" strokeWidth="4.5" strokeLinecap="round" className="opacity-80 animate-pulse" /> {/* Pectoral/Tricep strain heatmap */}
                <line x1="22" y1="21" x2="28" y2="34" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                <line x1="28" y1="34" x2="24" y2="42" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
                
                {/* Hand target anchor */}
                <circle cx="24" cy="42" r="2" fill="#047857" />
                {/* Pectoral/Chest focus line */}
                <path d="M22 25 Q 32 23 28 32" fill="none" stroke="#F87171" strokeWidth="2" className="animate-pulse" />
              </g>
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-emerald-400 bg-[#0F1014]/90 px-1.5 py-0.5 rounded border border-emerald-800/30 uppercase tracking-widest">
              CHEST & TRICEP LOAD
            </div>
          </div>
        );
      case 'Kegel':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-16 h-16 text-purple-400 overflow-visible animate-kegel-squeeze" viewBox="0 0 60 60">
              {/* Concentric scientific reference grids */}
              <circle cx="30" cy="30" r="26" fill="none" stroke="#A855F7" strokeWidth="1" strokeDasharray="2 3" strokeOpacity="0.2" />
              <circle cx="30" cy="30" r="20" fill="none" stroke="#A855F7" strokeWidth="1" strokeDasharray="3 3" strokeOpacity="0.3" />
              <circle cx="30" cy="30" r="14" fill="none" stroke="#A855F7" strokeWidth="1" strokeOpacity="0.4" />
              
              {/* Pelvic base model */}
              <path d="M 18 20 Q 30 14 42 20 Q 46 36 30 46 Q 14 36 18 20 Z" fill="url(#kegelGrad)" stroke="#C084FC" strokeWidth="1.5" strokeOpacity="0.8" />
              
              {/* Core pulsing contraction indicator */}
              <circle cx="30" cy="32" r="6" fill="#D8B4FE" className="animate-ping opacity-40" />
              <circle cx="30" cy="32" r="4.5" fill="#C084FC" />
              
              <defs>
                <radialGradient id="kegelGrad">
                  <stop offset="0%" stopColor="#A855F7" stopOpacity="0.4" stopID="kegelGrad-stop-1" />
                  <stop offset="100%" stopColor="#C084FC" stopOpacity="0.05" stopID="kegelGrad-stop-2" />
                </radialGradient>
              </defs>
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-purple-400 bg-[#0D0A14]/90 px-1.5 py-0.5 rounded border border-purple-800/30 uppercase tracking-widest">
              PELVIC FLOOR VECTOR
            </div>
          </div>
        );
      case 'Abs':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-18 h-14 text-emerald-400 overflow-visible" viewBox="0 0 60 50">
              <line x1="5" y1="40" x2="55" y2="40" stroke="#374151" strokeWidth="1.5" />
              
              {/* Stable pelvic floor and lower body */}
              <path d="M36 40 L 48 30 L 54 40" fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
              <circle cx="36" cy="40" r="2" fill="#047857" /> {/* Hip anchor */}
              
              {/* Crunching spine & torso */}
              <g className="animate-crunch origin-[36px_40px]">
                {/* Spine curve */}
                <path d="M36 40 Q 24 32 18 18" fill="none" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                {/* Abdominal core tension zone (Heat signature) */}
                <path d="M34 38 Q 25 31 22 21" fill="none" stroke="#EF4444" strokeWidth="5.5" strokeLinecap="round" className="opacity-85 animate-pulse" /> {/* Tension heat */}
                <path d="M34 38 Q 25 31 22 21" fill="none" stroke="#34C759" strokeWidth="3.5" strokeLinecap="round" />
                
                {/* Head */}
                <circle cx="16" cy="12" r="4.5" fill="#34C759" />
                {/* Neck node */}
                <circle cx="18" cy="18" r="1.5" fill="#10B981" />
                {/* Arm curled to head */}
                <path d="M 18 18 Q 12 16 16 12" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" />
              </g>
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-emerald-400 bg-[#0F1014]/90 px-1.5 py-0.5 rounded border border-emerald-800/30 uppercase tracking-widest">
              RECTUS ABDOMINIS STRESS
            </div>
          </div>
        );
      case 'Arms':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-16 h-16 text-emerald-400 overflow-visible" viewBox="0 0 60 60">
              {/* Shoulder pivot */}
              <circle cx="20" cy="18" r="3.5" fill="#10B981" />
              {/* Humerus (Upper arm - static) */}
              <line x1="20" y1="18" x2="30" y2="34" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
              
              {/* Elbow joint */}
              <circle cx="30" cy="34" r="2.5" fill="#34C759" />
              
              {/* Forearm and dumbbell rotating together */}
              <g className="animate-bicep-curl origin-[30px_34px]">
                {/* Forearm */}
                <line x1="30" y1="34" x2="48" y2="34" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                {/* Active Bicep muscle belly bulge - Heatmap indicator */}
                <path d="M 23 23 Q 32 18 30 31" fill="none" stroke="#EF4444" strokeWidth="5" strokeLinecap="round" className="opacity-80 animate-pulse" />
                <path d="M 23 23 Q 32 18 30 31" fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
                
                {/* Hand node */}
                <circle cx="48" cy="34" r="2" fill="#34C759" />
                
                {/* Dumbbell */}
                <g transform="translate(48, 34)">
                  <line x1="0" y1="-5" x2="0" y2="5" stroke="#9CA3AF" strokeWidth="2" />
                  <rect x="-3" y="-8" width="6" height="3" fill="#374151" rx="0.5" />
                  <rect x="-3" y="5" width="6" height="3" fill="#374151" rx="0.5" />
                  <circle cx="0" cy="0" r="1.5" fill="#FFFFFF" />
                </g>
              </g>
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-emerald-400 bg-[#0F1014]/90 px-1.5 py-0.5 rounded border border-emerald-800/30 uppercase tracking-widest">
              BICEP BRONCHIAL FLEX
            </div>
          </div>
        );
      case 'Flexibility':
        return (
          <div className="flex flex-col items-center justify-center h-full w-full relative">
            <svg className="w-18 h-14 text-emerald-400 overflow-visible" viewBox="0 0 60 50">
              <line x1="5" y1="42" x2="55" y2="42" stroke="#374151" strokeWidth="1.5" />
              
              <g className="animate-stretch-arch origin-bottom">
                {/* Inverted arch - Downward facing dog reference skeleton */}
                {/* Hands to Shoulder */}
                <line x1="14" y1="42" x2="24" y2="24" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />
                {/* Spine from Shoulder to Hip (glowing green alignment vector) */}
                <line x1="24" y1="24" x2="38" y2="18" stroke="#34C759" strokeWidth="3" strokeLinecap="round" />
                {/* Posterior chain heat zone */}
                <line x1="38" y1="18" x2="48" y2="42" stroke="#EF4444" strokeWidth="4.5" strokeLinecap="round" className="opacity-75 animate-pulse" />
                {/* Hip to Heel (Legs) */}
                <line x1="38" y1="18" x2="48" y2="42" stroke="#10B981" strokeWidth="3.5" strokeLinecap="round" />
                
                {/* Shoulder node */}
                <circle cx="24" cy="24" r="2.5" fill="#34C759" />
                {/* Head hanging low */}
                <circle cx="20" cy="28" r="4.5" fill="#34C759" />
                {/* Hip apex joint */}
                <circle cx="38" cy="18" r="3" fill="#10B981" />
                {/* Feet node */}
                <circle cx="48" cy="42" r="2" fill="#047857" />
                
                {/* Biomechanical force arrows */}
                <path d="M 38 12 L 38 6 M 38 6 L 35 9 M 38 6 L 41 9" fill="none" stroke="#FBBF24" strokeWidth="1.5" strokeLinecap="round" />
              </g>
            </svg>
            <div className="absolute bottom-1 text-[7px] font-black font-mono text-emerald-400 bg-[#0F1014]/90 px-1.5 py-0.5 rounded border border-emerald-800/30 uppercase tracking-widest">
              KINETIC RANGE ELONGATION
            </div>
          </div>
        );
      default:
        return (
          <div className="flex flex-col items-center animate-pulse">
            <Dumbbell className="w-8 h-8 text-neutral-600 transform -rotate-12" />
          </div>
        );
    }
  };

  return (
    <div className={`min-h-screen flex items-center justify-center p-0 md:p-6 transition-all duration-300 ${
      theme === 'dark' ? 'bg-[#0F1014]' : 'bg-[#E1E2E9]'
    }`}>
      {/* MOBILE DEVICE CONTAINER MOCKUP */}
      <div className={`w-full max-w-md h-full md:h-[840px] md:rounded-[40px] shadow-2xl relative overflow-hidden flex flex-col transition-all duration-300 border-0 md:border-8 ${
        theme === 'dark' 
          ? 'bg-[#121318] border-[#2C2D35] text-white' 
          : 'bg-[#F8F9FE] border-[#D1D2D9] text-[#1F1F1F]'
      }`}
      style={{ minHeight: '100vh', md: { minHeight: '840px' } } as any}>
        
        {/* ANDROID SYSTEM TOP BAR */}
        <div className={`px-5 pt-3 pb-2 flex justify-between items-center text-xs font-semibold select-none z-10 transition-colors ${
          theme === 'dark' ? 'bg-[#121318] text-white' : 'bg-[#F8F9FE] text-[#1F1F1F]'
        }`}>
          <span>9:41 AM</span>
          <div className="flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 opacity-80" />
            <Activity className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
            <div className="flex items-center gap-0.5 opacity-80">
              <span className="text-[10px]">LTE</span>
              <div className="w-5 h-2.5 border border-current rounded-sm p-0.5 flex items-center">
                <div className="bg-current h-full w-4 rounded-2xs"></div>
              </div>
            </div>
          </div>
        </div>

        {/* 1. SPLASH SCREEN */}
        {currentScreen === 'splash' && (
          <div className="absolute inset-0 z-50 bg-gradient-to-br from-[#121318] via-[#1A1C24] to-[#0F1014] flex flex-col justify-between p-8 items-center text-center">
            <div></div>
            <div className="flex flex-col items-center animate-bounce-slow">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#34C759] to-[#0A84FF] p-1 flex items-center justify-center shadow-lg shadow-emerald-950">
                <div className="w-full h-full bg-[#1A1C24] rounded-full flex items-center justify-center">
                  <Dumbbell className="w-11 h-11 text-emerald-400 transform -rotate-45" />
                </div>
              </div>
              <h1 className="text-4xl font-extrabold tracking-tight text-white mt-6 bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-blue-400">
                FitMaster AI
              </h1>
              <p className="text-[#C4C7C5] text-sm mt-2 tracking-wide font-medium">
                INTELLIGENT KINETIC RECONSTITUTION
              </p>
            </div>
            <div className="flex flex-col items-center w-full">
              <div className="w-16 h-1 bg-neutral-800 rounded-full overflow-hidden mb-2">
                <div className="h-full bg-emerald-400 w-1/2 animate-infinite-loading"></div>
              </div>
              <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-mono">
                INITIALIZING CORE NEURAL FRAMEWORK
              </span>
            </div>
          </div>
        )}

        {/* 2. WELCOME / SIGN IN SCREEN */}
        {currentScreen === 'welcome' && (
          <div className="flex-1 flex flex-col justify-between p-6 text-center">
            <div className="pt-2">
              <div className="relative h-44 w-full rounded-2xl overflow-hidden mb-3 shadow-lg border border-neutral-800">
                <img 
                  src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80" 
                  alt="Trainer Athlete Coaching"
                  className="absolute inset-0 w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121318] via-black/40 to-transparent"></div>
                <div className="absolute bottom-3 left-3 right-3 text-left">
                  <span className="text-[8px] font-black bg-emerald-400 text-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Bio-Kinetic AI
                  </span>
                  <h3 className="text-xl font-extrabold text-white mt-1 leading-tight tracking-tight">Elite Real-Time Coaching</h3>
                </div>
              </div>
              <h2 className="text-2xl font-black tracking-tight mb-1">FitMaster AI</h2>
              <p className="text-neutral-400 text-xs max-w-xs mx-auto px-2">
                Elite physical coaching, real-time interactive anatomy engine, and bio-adaptive routines at your command.
              </p>
            </div>

            {/* Premium Mock Card */}
            <div className="bg-gradient-to-r from-[#1A1C24] to-[#242731] border border-neutral-800 rounded-2xl p-4 text-left my-4 shadow-md relative overflow-hidden">
              <div className="absolute right-[-10px] top-[-10px] w-20 h-20 bg-emerald-500/10 rounded-full blur-xl"></div>
              <div className="flex items-center gap-2 mb-1.5">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                <span className="text-xs font-bold text-amber-400 tracking-wider uppercase">PREMIUM PROTOCOL ACTIVATED</span>
              </div>
              <p className="text-xs text-neutral-400">
                Zero telemetry delay, 300+ full HD workouts, voice guided bio-synchronization and Gemini AI generation.
              </p>
            </div>

            <div className="flex flex-col gap-3.5 mb-6">
              <button 
                onClick={() => setCurrentScreen('onboarding')}
                id="btn-guest-login"
                className="w-full py-4 px-6 rounded-2xl bg-[#0A84FF] text-white font-bold hover:bg-blue-600 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20"
              >
                <Smartphone className="w-4 h-4" />
                Start as Guest (Instant Access)
              </button>
              <button 
                onClick={() => {
                  setIsPremium(true);
                  setCurrentScreen('onboarding');
                }}
                id="btn-google-login"
                className="w-full py-3.5 px-6 rounded-2xl bg-white text-black font-semibold border border-neutral-300 hover:bg-neutral-100 transition flex items-center justify-center gap-2.5 shadow"
              >
                <span className="text-red-500 font-extrabold">G</span>
                Sign in with Google
              </button>
              <button 
                onClick={() => setCurrentScreen('onboarding')}
                id="btn-email-login"
                className="w-full py-3 text-xs text-neutral-400 hover:text-white transition font-medium"
              >
                Or enter with Email and Password
              </button>
            </div>
          </div>
        )}

        {/* 3. PERSONALIZED ONBOARDING QUESTIONNAIRE */}
        {currentScreen === 'onboarding' && (
          <div className="flex-1 flex flex-col justify-between p-6">
            <div className="overflow-y-auto max-h-[640px] pr-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-1 bg-emerald-400 rounded-full"></div>
                <span className="text-xs font-bold tracking-widest text-emerald-400 uppercase">Onboarding Profile</span>
              </div>

              <h3 className="text-2xl font-bold tracking-tight mb-2">Personalize Your Protocol</h3>
              <p className="text-xs text-neutral-400 mb-6">
                Our generative engine synchronizes workouts perfectly with your physical parameters and hardware setup.
              </p>

              {/* Questionnaire Form */}
              <div className="space-y-4">
                {/* Age & Gender Row */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase">Age</label>
                    <input 
                      type="number" 
                      value={age}
                      onChange={e => setAge(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-sm font-bold text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase">Gender</label>
                    <select 
                      value={gender}
                      onChange={e => setGender(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-sm font-bold text-white focus:border-emerald-500 outline-none"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                {/* Height & Weight Row */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase">Height (cm)</label>
                    <input 
                      type="number" 
                      value={height}
                      onChange={e => setHeight(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-sm font-bold text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase">Weight (kg)</label>
                    <input 
                      type="number" 
                      value={weight}
                      onChange={e => setWeight(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-sm font-bold text-white focus:border-emerald-500 outline-none"
                    />
                  </div>
                </div>

                {/* Goal Selector */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase">Core Fitness Goal</label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['Weight Loss', 'Six Pack', 'Chest', 'Arms', 'Legs', 'Full Body', 'Flexibility', 'Kegel Exercises'].map(g => (
                      <button
                        key={g}
                        onClick={() => setGoal(g)}
                        className={`p-2.5 rounded-xl text-left font-bold transition border ${
                          goal === g 
                            ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                            : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-850'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Equipment & Experience Row */}
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase font-bold">Equipment</label>
                    <select 
                      value={equipment}
                      onChange={e => setEquipment(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-bold text-white outline-none"
                    >
                      <option value="Bodyweight Only">Bodyweight</option>
                      <option value="Dumbbells Only">Dumbbells</option>
                      <option value="Full Gym Set">Full Gym</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-400 mb-1.5 uppercase font-bold">Experience</label>
                    <select 
                      value={experience}
                      onChange={e => setExperience(e.target.value)}
                      className="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-bold text-white outline-none"
                    >
                      <option value="Beginner">Beginner</option>
                      <option value="Intermediate">Intermediate</option>
                      <option value="Advanced">Advanced</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-800">
              <button 
                onClick={handleGeneratePlan}
                disabled={isGeneratingPlan}
                id="btn-generate-plan"
                className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 to-blue-500 hover:opacity-90 text-white font-extrabold flex items-center justify-center gap-2 shadow"
              >
                {isGeneratingPlan ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    AI Plan Synthesis Active...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                    Generate AI Workout Cycle
                  </>
                )}
              </button>
              <p className="text-[10px] text-center text-neutral-500 mt-2">
                Fits and schedules standard full-body, arms, legs, or Kegel exercises.
              </p>
            </div>
          </div>
        )}

        {/* MAIN APPLICATION CONTAINER (TABS SCREEN) */}
        {(currentScreen === 'home' || currentScreen === 'workout_complete') && (
          <div className="flex-1 flex flex-col justify-between overflow-hidden relative">
            
            {/* TOP BAR / PANEL HEADER */}
            <div className="px-5 py-3 flex justify-between items-center border-b border-neutral-800/20">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <Dumbbell className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <span className="text-[10px] font-bold tracking-widest text-neutral-400 uppercase">FitMaster AI</span>
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-semibold">Welcome, Trainer</span>
                    {isPremium && <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-bounce" />}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Theme Selector */}
                <button 
                  onClick={toggleTheme}
                  className="p-2 rounded-xl hover:bg-neutral-800/10 transition"
                  title="Switch theme"
                >
                  {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
                </button>

                {/* Subscription Badge */}
                {!isPremium ? (
                  <button 
                    onClick={() => setShowPremiumModal(true)}
                    className="py-1 px-2.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[10px] font-bold tracking-wider animate-pulse flex items-center gap-1"
                  >
                    <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                    GO PREMIUM
                  </button>
                ) : (
                  <div className="py-1 px-2.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-bold">
                    PRO ACCESS
                  </div>
                )}
              </div>
            </div>

            {/* MAIN VIEWS BY ACTIVE TAB */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              
              {/* SCREEN-SPECIFIC COMPLETION CARD (Overlay style overlay when completed) */}
              {currentScreen === 'workout_complete' && (
                <div className="bg-gradient-to-br from-emerald-500 to-teal-700 rounded-3xl p-5 text-white shadow-xl relative overflow-hidden mb-4">
                  <div className="absolute top-[-20px] right-[-20px] w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 bg-white/20 rounded-full">
                      <Trophy className="w-6 h-6 text-yellow-300 fill-yellow-300" />
                    </div>
                    <button 
                      onClick={() => setCurrentScreen('home')}
                      className="text-white/80 hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <h4 className="text-xl font-black">Workout Reconstitution Complete!</h4>
                  <p className="text-xs text-white/95 mt-1">
                    Telemetry data saved to local state. Form integrity remained nominal.
                  </p>
                  <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                    <div className="bg-white/10 rounded-xl p-2">
                      <span className="block text-lg font-black text-white">{streak} days</span>
                      <span className="text-[9px] text-white/80 uppercase">Active Streak</span>
                    </div>
                    <div className="bg-white/10 rounded-xl p-2">
                      <span className="block text-lg font-black text-white">+180</span>
                      <span className="text-[9px] text-white/80 uppercase">Kcal Burned</span>
                    </div>
                    <div className="bg-white/10 rounded-xl p-2">
                      <span className="block text-lg font-black text-white">100%</span>
                      <span className="text-[9px] text-white/80 uppercase">Symmetry</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => setCurrentScreen('home')}
                    className="w-full mt-4 py-2.5 rounded-xl bg-white text-emerald-600 font-bold text-xs"
                  >
                    Return to Dashboard
                  </button>
                </div>
              )}

              {/* TAB 1: HOME DASHBOARD */}
              {activeTab === 'home' && (
                <div className="space-y-4">
                  {/* Bio Stats Grid */}
                  <div className="grid grid-cols-4 gap-2">
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-2.5 text-center flex flex-col justify-between">
                      <div className="flex justify-center"><Flame className="w-4 h-4 text-orange-400" /></div>
                      <span className="text-[10px] text-neutral-400 mt-1">Calories</span>
                      <span className="text-sm font-black text-white">{caloriesBurned} <span className="text-[8px]">kcal</span></span>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-2.5 text-center flex flex-col justify-between">
                      <div className="flex justify-center"><Calendar className="w-4 h-4 text-emerald-400" /></div>
                      <span className="text-[10px] text-neutral-400 mt-1">Streak</span>
                      <span className="text-sm font-black text-white">{streak} <span className="text-[8px]">days</span></span>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-2.5 text-center flex flex-col justify-between">
                      <div className="flex justify-center"><Footprints className="w-4 h-4 text-blue-400" /></div>
                      <span className="text-[10px] text-neutral-400 mt-1">Steps</span>
                      <span className="text-sm font-black text-white">{stepsCount}</span>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-2.5 text-center flex flex-col justify-between">
                      <div className="flex justify-center"><Target className="w-4 h-4 text-purple-400" /></div>
                      <span className="text-[10px] text-neutral-400 mt-1">BMI Index</span>
                      <span className="text-sm font-black text-white">{bmiValue}</span>
                    </div>
                  </div>

                  {/* STEP SIMULATOR CONTROLLER */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`p-1.5 rounded-lg ${isSimulatingSteps ? 'bg-emerald-500/20 text-emerald-400 animate-pulse' : 'bg-neutral-800 text-neutral-400'}`}>
                        <Footprints className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-neutral-400 uppercase">Interactive Pedometer</span>
                        <h5 className="text-xs font-semibold text-white">Simulate Workout Walking</h5>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setIsSimulatingSteps(!isSimulatingSteps);
                        playBeep(850, 100);
                        if (!isSimulatingSteps) speak("Simulated pedometer walking enabled. Enjoy your training walk.");
                      }}
                      className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition ${
                        isSimulatingSteps 
                          ? 'bg-orange-500 text-white' 
                          : 'bg-neutral-800 text-neutral-300'
                      }`}
                    >
                      {isSimulatingSteps ? 'STOP WALKING' : 'START WALK'}
                    </button>
                  </div>

                  {/* ACTIVE WORKOUT OF THE DAY */}
                  <div className="bg-gradient-to-r from-[#1E293B] to-[#0F172A] border border-slate-800 rounded-3xl p-5 shadow-lg relative overflow-hidden">
                    <div className="absolute right-[-15px] top-[-15px] w-28 h-28 bg-[#38BDF8]/10 rounded-full blur-xl"></div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-5 h-5 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center">
                        <CalendarDays className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[9px] font-bold text-sky-400 uppercase tracking-widest">TODAY'S AI PROTOCOL</span>
                    </div>
                    <h4 className="text-lg font-black text-white">{todayWorkout.title}</h4>
                    <p className="text-xs text-neutral-400 mt-1 max-w-xs leading-relaxed">
                      {workoutPlan ? workoutPlan.weeklyFocus : "Adaptive strength program focusing on dynamic form replication and chest activation."}
                    </p>

                    {/* Exercise List with lock indicators */}
                    <div className="mt-4 space-y-1.5">
                      {todayWorkout.exercises.map((ex, exIdx) => {
                        const freeLimit = Math.max(1, Math.ceil(todayWorkout.exercises.length * 0.3));
                        const isLocked = !isPremium && exIdx >= freeLimit;
                        return (
                          <div 
                            key={exIdx} 
                            onClick={() => {
                              if (!isLocked) {
                                setSelectedDetailExercise(ex);
                                setPreviousScreenBeforeDetails('home');
                                setCurrentScreen('exercise_details');
                                speak(`Opening form analysis for ${ex.name}.`);
                              } else {
                                setShowPremiumModal(true);
                              }
                            }}
                            className={`flex items-center justify-between p-2 rounded-xl text-xs transition cursor-pointer ${
                              isLocked 
                                ? 'bg-neutral-950/60 border border-neutral-900/40 text-neutral-500' 
                                : 'bg-neutral-950/35 border border-neutral-800/20 text-neutral-200 hover:border-emerald-500/40'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[9px] text-neutral-500">#{exIdx + 1}</span>
                              <span className={`font-semibold ${isLocked ? 'line-through opacity-50' : ''}`}>{ex.name}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10px] text-neutral-400">{ex.sets}x {ex.reps}</span>
                              {isLocked && <Lock className="w-3 h-3 text-amber-500" />}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <div className="flex items-center gap-4 mt-4 text-xs font-semibold text-neutral-300">
                      <span className="flex items-center gap-1"><Dumbbell className="w-3.5 h-3.5 text-neutral-400" /> {todayWorkout.exercises.length} Exercises</span>
                      <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-neutral-400" /> {todayWorkout.calories} Kcal</span>
                    </div>
                    
                    <button
                      onClick={() => launchWorkout(todayWorkout.title, todayWorkout.exercises)}
                      className="w-full mt-4 py-3 bg-gradient-to-r from-emerald-400 to-blue-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 hover:opacity-90 transition shadow-lg shadow-emerald-500/10"
                    >
                      <Play className="w-4 h-4 text-white fill-current" />
                      START TODAY'S WORKOUT
                    </button>
                  </div>

                  {/* WATER WATER TRACKER */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <Droplet className="w-4.5 h-4.5 text-blue-400 fill-blue-500" />
                        <span className="text-xs font-bold text-white">Water Balance</span>
                      </div>
                      <div className="text-lg font-black text-white">
                        {waterIntake} <span className="text-xs font-normal text-neutral-400">/ 2000 ml</span>
                      </div>
                      <div className="w-32 h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-400 to-sky-400 transition-all duration-500" 
                          style={{ width: `${Math.min(100, (waterIntake / 2000) * 100)}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => addWater(250)}
                        className="py-2.5 px-3 rounded-xl bg-blue-500/10 text-blue-400 font-bold text-xs hover:bg-blue-500/20 active:scale-95 transition"
                      >
                        +250ml
                      </button>
                      <button 
                        onClick={() => addWater(500)}
                        className="py-2.5 px-3 rounded-xl bg-blue-500/10 text-blue-400 font-bold text-xs hover:bg-blue-500/20 active:scale-95 transition"
                      >
                        +500ml
                      </button>
                    </div>
                  </div>

                  {/* DYNAMIC MOTIVATION QUOTE CARD */}
                  <div className="bg-gradient-to-br from-[#1C1D24] to-[#121318] border border-neutral-800/80 rounded-2xl p-4 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-emerald-400"></div>
                    <span className="text-[9px] font-bold tracking-widest text-emerald-400 uppercase">Adaptive Inspiration</span>
                    <p className="text-xs italic text-neutral-300 mt-1.5 leading-relaxed font-serif">
                      "{activeQuote.quote}"
                    </p>
                    <span className="block text-[10px] text-neutral-500 text-right mt-1 font-semibold">— {activeQuote.author}</span>
                  </div>

                  {/* SIMULATED ADMOB BANNER FOR NON-PREMIUM */}
                  {!isPremium && (
                    <div className="bg-[#1C1F2B] border border-neutral-800 rounded-xl p-2 text-center relative overflow-hidden flex items-center justify-between px-4">
                      <span className="absolute left-1 top-1 bg-neutral-800 text-[8px] px-1 rounded text-neutral-500 scale-90">Ad</span>
                      <div className="text-left pl-3">
                        <span className="block text-[9px] font-black text-amber-400 uppercase tracking-widest">FitMaster Pro Bundle</span>
                        <span className="text-[10px] text-neutral-400">Unlock custom muscle builders, full Kegel trainer & ads removal.</span>
                      </div>
                      <button 
                        onClick={() => setShowPremiumModal(true)}
                        className="text-[9px] font-bold text-white bg-amber-500 px-2 py-1 rounded hover:bg-amber-600"
                      >
                        UPGRADE
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: WORKOUTS PROGRAMS */}
              {activeTab === 'workouts' && (
                <div className="space-y-4">
                  {/* GENERATED CYCLE VIEW */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4">
                    <div className="flex justify-between items-center mb-3">
                      <div>
                        <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wide">ACTIVE PLAN</span>
                        <h4 className="text-md font-bold text-white">{workoutPlan ? workoutPlan.planName : "Custom Conditioning Plan"}</h4>
                      </div>
                      <button 
                        onClick={() => setCurrentScreen('onboarding')}
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition"
                        title="Re-generate plan"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Expandable 7-day view */}
                    <div className="space-y-2">
                      {(workoutPlan ? workoutPlan.days : [
                        { dayNumber: 1, title: 'Day 1: Chest & Abs Foundation', focus: 'Chest, Abs', restDay: false, description: 'Standard starter exercises.' },
                        { dayNumber: 2, title: 'Day 2: Full Body Conditioning', focus: 'Legs, Arms, Abs', restDay: false, description: 'Dynamic bodyweight routine.' },
                        { dayNumber: 3, title: 'Day 3: Active Rest Day', focus: 'Rest', restDay: true, description: 'Hydrate and stretch.' },
                        { dayNumber: 4, title: 'Day 4: Legs & Core Power', focus: 'Legs, Core', restDay: false, description: 'Targeting glutes and thighs.' }
                      ]).map((day, idx) => (
                        <div 
                          key={idx} 
                          onClick={() => {
                            if (!day.restDay) {
                              const exs = day.exercises && day.exercises.length > 0 
                                ? day.exercises 
                                : DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Chest');
                              launchWorkout(day.title, exs);
                            } else {
                              speak("Today is configured as a strategic recovery interval. Spend time stretches or breathing.");
                            }
                          }}
                          className={`p-3 rounded-2xl flex items-center justify-between cursor-pointer transition border hover:scale-[1.01] ${
                            day.restDay 
                              ? 'bg-neutral-950/40 border-neutral-900 text-neutral-500' 
                              : 'bg-neutral-900 border-neutral-800 text-white hover:border-emerald-500/40'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                              day.restDay ? 'bg-neutral-900 text-neutral-600' : 'bg-emerald-500/10 text-emerald-400'
                            }`}>
                              D{day.dayNumber}
                            </div>
                            <div>
                              <h5 className="text-xs font-bold">{day.title}</h5>
                              <p className="text-[10px] text-neutral-400 mt-0.5">{day.focus}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                            {day.restDay ? 'RECOVERY' : <><Play className="w-3 h-3 fill-current" /> START</>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* SPECIALIZED WORKOUT MODULES: SIX PACK, CHEST BUILDER, KEGELS */}
                  <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-widest pt-2">Specialist Trainers</h4>

                  {/* Kegel Trainer Program */}
                  <div className="bg-gradient-to-r from-purple-950 to-[#2A1B3D] border border-purple-900/60 rounded-3xl p-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <span className="text-[9px] bg-purple-500/20 text-purple-300 font-bold px-2 py-0.5 rounded-full uppercase">Pelvic Alignment</span>
                        <h5 className="text-sm font-bold text-white">Kegel Pelvic Trainer</h5>
                        <p className="text-xs text-neutral-400">Rhythmic pelvic-floor contraction simulator. {!isPremium && <span className="text-purple-300 font-bold">(30% Free Trial)</span>}</p>
                      </div>
                      <button
                        onClick={() => {
                          launchKegelTrainer("Kegel Isometric Trainer");
                        }}
                        className="py-2.5 px-4 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" /> {!isPremium ? 'TRY FREE (30%)' : 'START'}
                      </button>
                    </div>
                  </div>

                  {/* Six-Pack 30-Day Challenge */}
                  <div className="bg-gradient-to-r from-orange-950/60 to-[#2B1B15] border border-orange-900/40 rounded-3xl p-4">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <span className="text-[9px] bg-orange-500/20 text-orange-300 font-bold px-2 py-0.5 rounded-full uppercase">30-Day Challenge</span>
                        <h5 className="text-sm font-bold text-white">Six-Pack Sculptor</h5>
                        <div className="flex items-center gap-2 text-xs text-neutral-400">
                          <span>Day {sixPackChallengeDay} / 30</span>
                          <span>•</span>
                          {!isPremium && sixPackChallengeDay > 9 ? (
                            <span className="text-amber-400 font-bold flex items-center gap-1"><Lock className="w-3 h-3" /> Locked</span>
                          ) : (
                            <span className="text-orange-400 font-semibold">Core Strength: {coreStrengthScore}%</span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          if (isPremium || sixPackChallengeDay <= 9) {
                            launchWorkout(`Six-Pack Sculpt Day ${sixPackChallengeDay}`, DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Abs'));
                          } else {
                            setShowPremiumModal(true);
                            speak("Six Pack 30-Day program is restricted after Day 9 under our 30% free program. Unlock Premium to continue your streak.");
                          }
                        }}
                        className="py-2 px-4 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs flex items-center gap-1 shadow"
                      >
                        {!isPremium && sixPackChallengeDay > 9 ? <Lock className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />} CONTINUE
                      </button>
                    </div>
                  </div>

                  {/* Chest Builder & Overload Suggestions */}
                  <div className="bg-[#15231A] border border-emerald-900/40 rounded-3xl p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full uppercase">Hypertrophy Engine</span>
                        <h5 className="text-sm font-bold text-white">Advanced Chest Builder</h5>
                        <p className="text-xs text-neutral-400">Progressive overload suggestions: increase load or reps by 5% weekly.</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                      <button 
                        onClick={() => launchWorkout("Chest: Home Bodyweight", DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Chest' && e.level === 'Beginner'))}
                        className="bg-[#1E2E24] hover:bg-[#25392D] rounded-xl p-2.5 font-bold text-emerald-400"
                      >
                        HOME BODY
                      </button>
                      <button 
                        onClick={() => launchWorkout("Chest: Dumbbell Workout", DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Chest' && e.level === 'Intermediate'))}
                        className="bg-[#1E2E24] hover:bg-[#25392D] rounded-xl p-2.5 font-bold text-emerald-400 flex items-center justify-center gap-1"
                      >
                        {!isPremium && <span className="bg-amber-400/20 text-amber-400 text-[8px] px-1 py-0.5 rounded font-black font-mono">30% FREE</span>} DUMBBELLS
                      </button>
                      <button 
                        onClick={() => launchWorkout("Chest: Gym Heavy Press", DEFAULT_LIBRARY_EXERCISES.filter(e => e.category === 'Chest'))}
                        className="bg-[#1E2E24] hover:bg-[#25392D] rounded-xl p-2.5 font-bold text-emerald-400 flex items-center justify-center gap-1"
                      >
                        {!isPremium && <span className="bg-amber-400/20 text-amber-400 text-[8px] px-1 py-0.5 rounded font-black font-mono">30% FREE</span>} GYM PRO
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: EXERCISE LIBRARY */}
              {activeTab === 'library' && (
                <div className="space-y-4">
                  {/* Search and Category selectors */}
                  <div className="space-y-2">
                    <div className="relative">
                      <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-neutral-500" />
                      <input 
                        type="text" 
                        placeholder="Search 300+ exercises..." 
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs focus:border-emerald-500 outline-none"
                      />
                    </div>

                    <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
                      {['All', 'Chest', 'Abs', 'Legs', 'Arms', 'Flexibility', 'Kegel'].map(cat => (
                        <button
                          key={cat}
                          onClick={() => setFilterCategory(cat)}
                          className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition whitespace-nowrap ${
                            filterCategory === cat 
                              ? 'bg-emerald-500 text-white' 
                              : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:bg-neutral-850'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* List of filtered exercises */}
                  <div className="space-y-3">
                    {filteredExercises.map((ex, idx) => {
                      const freeLimit = Math.max(1, Math.ceil(filteredExercises.length * 0.3));
                      const isLocked = !isPremium && idx >= freeLimit;
                      return (
                        <div 
                          key={idx} 
                          className={`bg-neutral-900 border rounded-2xl p-4 space-y-2.5 relative transition-all ${
                            isLocked ? 'border-amber-500/20 opacity-80' : 'border-neutral-850'
                          }`}
                        >
                          {isLocked && (
                            <div className="absolute inset-0 bg-neutral-950/75 rounded-2xl backdrop-blur-xs flex flex-col items-center justify-center z-10 p-4 text-center">
                              <Lock className="w-8 h-8 text-amber-400 mb-1.5 animate-bounce" />
                              <span className="text-xs font-black text-amber-400 uppercase tracking-widest">Premium Exercise</span>
                              <p className="text-[10px] text-neutral-400 mt-0.5 max-w-[220px] leading-relaxed">
                                Under our 30% free program, this is a Pro Exercise. Upgrade to Pro (₹100/mo in India or $3/mo international) to unlock the remaining 70% of the library!
                              </p>
                              <button
                                onClick={() => setShowPremiumModal(true)}
                                className="mt-2.5 py-1.5 px-3 bg-amber-500 text-black text-[10px] font-black rounded-lg hover:bg-amber-400"
                              >
                                UNLOCK NOW
                              </button>
                            </div>
                          )}
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[9px] bg-neutral-800 px-2 py-0.5 rounded text-neutral-400 font-bold uppercase mr-1.5">{ex.category}</span>
                              <span className="text-[9px] bg-neutral-800 px-2 py-0.5 rounded text-neutral-400 font-bold uppercase">{ex.level}</span>
                              <h5 className="text-sm font-bold text-white mt-1">{ex.name}</h5>
                            </div>
                            <div className="flex gap-2 items-center">
                              <button 
                                onClick={() => {
                                  setSelectedDetailExercise(ex);
                                  setPreviousScreenBeforeDetails('home');
                                  setCurrentScreen('exercise_details');
                                  speak(`Accessing advanced biomechanics guide for ${ex.name}.`);
                                }}
                                className="p-1.5 px-2 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 transition flex items-center gap-1 font-bold text-[9px] tracking-wider uppercase shrink-0"
                                title="Learn Premium Form Details"
                              >
                                <Sparkles className="w-3.5 h-3.5 fill-current text-amber-400" />
                                <span>Form Details</span>
                              </button>
                              <button 
                                onClick={() => toggleFavorite(ex.name)}
                                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 transition"
                              >
                                <Heart className={`w-4 h-4 ${favorites.includes(ex.name) ? 'text-red-500 fill-current' : 'text-neutral-400'}`} />
                              </button>
                              <button 
                                onClick={() => launchWorkout(`Individual: ${ex.name}`, [ex])}
                                className="p-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 transition"
                              >
                                <Play className="w-4 h-4 fill-current" />
                              </button>
                            </div>
                          </div>

                          {/* HD ANIMATION BLOCK (Interactive CSS Illustration + Real Photo) */}
                          <div className="bg-neutral-950 rounded-xl h-28 grid grid-cols-2 overflow-hidden relative border border-neutral-900">
                            <div className="relative h-full w-full">
                              <img 
                                src={ex.image || CATEGORY_IMAGES[ex.category] || DEFAULT_CATEGORY_IMAGE} 
                                alt={ex.name}
                                className="absolute inset-0 w-full h-full object-cover opacity-80 hover:scale-105 transition duration-500"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-neutral-950"></div>
                              <span className="absolute left-2.5 top-2 text-[7px] font-black text-white bg-black/60 px-1.5 py-0.5 rounded uppercase tracking-wider">
                                REFERENCE
                              </span>
                            </div>
                            <div className="flex items-center justify-center relative h-full">
                              <span className="absolute right-2.5 top-2 text-[7px] font-bold text-neutral-500 uppercase font-mono tracking-widest">
                                KINETIC ANATOMY
                              </span>
                              {renderExerciseVisual(ex.category)}
                            </div>
                          </div>

                          <div className="space-y-1">
                            <span className="text-[10px] text-neutral-400 block font-bold uppercase">Instructions</span>
                            <p className="text-xs text-neutral-300 leading-relaxed">{ex.instructions}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-neutral-850 text-[10px] text-neutral-400">
                            <div><span className="font-bold text-red-400">Mistake:</span> {ex.tips.split(',')[0] || 'Poor postural focus.'}</div>
                            <div><span className="font-bold text-emerald-400">Safety:</span> Control eccentric deceleration.</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 4: PROGRESS TRACKER */}
              {activeTab === 'progress' && (
                <div className="space-y-4">
                  {/* Weight tracker & custom interactive SVG chart */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 space-y-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-[10px] text-neutral-400 font-bold uppercase">WEIGHT TRAJECTORY</span>
                        <h4 className="text-md font-bold text-white">Body Weight Log</h4>
                      </div>
                      <form onSubmit={handleAddWeight} className="flex gap-1.5">
                        <input 
                          type="text" 
                          placeholder="70.5" 
                          value={newWeightInput}
                          onChange={e => setNewWeightInput(e.target.value)}
                          className="w-16 px-2.5 py-1.5 rounded-xl bg-neutral-950 border border-neutral-850 text-xs font-bold text-white text-center outline-none"
                        />
                        <button type="submit" className="p-2 rounded-xl bg-emerald-500 text-white font-bold text-xs hover:bg-emerald-600">
                          <Plus className="w-4 h-4" />
                        </button>
                      </form>
                    </div>

                    {renderWeightGraph()}
                  </div>

                  {/* Body measurements tracker */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 space-y-3">
                    <span className="text-[10px] text-neutral-400 font-bold uppercase">BODY CONTOURS (CM)</span>
                    <div className="grid grid-cols-2 gap-3">
                      {(Object.keys(bodyMeasurements) as Array<keyof typeof bodyMeasurements>).map((key) => {
                        const val = bodyMeasurements[key];
                        return (
                          <div key={key} className="bg-neutral-950 p-2.5 rounded-xl flex flex-col justify-between">
                            <span className="text-[10px] text-neutral-500 capitalize">{key}</span>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-sm font-bold text-white">{val} cm</span>
                              <div className="flex gap-1">
                                <button 
                                  onClick={() => {
                                    setBodyMeasurements(prev => ({ ...prev, [key]: prev[key] - 1 }));
                                    playBeep(600, 50);
                                  }}
                                  className="w-5 h-5 rounded-md bg-neutral-800 text-neutral-300 flex items-center justify-center text-xs font-extrabold"
                                >
                                  -
                                </button>
                                <button 
                                  onClick={() => {
                                    setBodyMeasurements(prev => ({ ...prev, [key]: prev[key] + 1 }));
                                    playBeep(800, 50);
                                  }}
                                  className="w-5 h-5 rounded-md bg-neutral-800 text-neutral-300 flex items-center justify-center text-xs font-extrabold"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* ACHIEVEMENT BADGES */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 space-y-2.5">
                    <span className="text-[10px] text-neutral-400 font-bold uppercase block">Unlocked Achievements</span>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs font-semibold">
                      {[
                        { id: 'streak_3', title: 'Streak Starter', desc: 'Hold 3-day workout sequence.', icon: Trophy, color: 'text-amber-400' },
                        { id: 'water_cup', title: 'Hydrated Core', desc: 'Drink water twice.', icon: Droplet, color: 'text-sky-400' },
                        { id: 'workout_one', title: 'Iron Resolve', desc: 'Completed first smart routine.', icon: Award, color: 'text-emerald-400' },
                        { id: 'kegel_master', title: 'Pelvic Master', desc: 'Complete high-tension Kegel hold.', icon: Sparkles, color: 'text-purple-400' },
                        { id: 'streak_4', title: 'Aesthetic Symmetry', desc: 'Sustained streak to Day 4.', icon: Flame, color: 'text-red-400' },
                        { id: 'water_champion', title: 'Water God', desc: 'Conquer 2000ml in one day.', icon: Crown, color: 'text-yellow-300' }
                      ].map(badge => {
                        const isUnlocked = unlockedBadges.includes(badge.id);
                        return (
                          <div 
                            key={badge.id} 
                            className={`p-3 rounded-2xl flex flex-col items-center justify-between border ${
                              isUnlocked 
                                ? 'bg-[#1E1F25] border-neutral-800 text-white' 
                                : 'bg-neutral-950/40 border-neutral-900 text-neutral-600'
                            }`}
                          >
                            <badge.icon className={`w-8 h-8 mb-1.5 ${isUnlocked ? badge.color : 'text-neutral-700 opacity-40'}`} />
                            <span className="block text-[10px] font-bold tracking-tight">{badge.title}</span>
                            <span className="block text-[8px] text-neutral-500 scale-90 leading-tight mt-0.5">{badge.desc}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: PROFILE & SETTINGS */}
              {activeTab === 'profile' && (
                <div className="space-y-4">
                  {/* Bio details and BMI summary */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 flex flex-col items-center text-center space-y-3">
                    <div className="relative">
                      <div className="w-18 h-18 rounded-full bg-gradient-to-tr from-emerald-400 to-blue-500 flex items-center justify-center shadow-lg">
                        <User className="w-8 h-8 text-white" />
                      </div>
                      {isPremium && (
                        <div className="absolute right-[-2px] bottom-[-2px] bg-amber-500 rounded-full p-1 border border-white">
                          <Crown className="w-3.5 h-3.5 text-white fill-current" />
                        </div>
                      )}
                    </div>

                    <div className="space-y-0.5">
                      <h4 className="text-base font-bold text-white">Advanced Kinetic User</h4>
                      <p className="text-xs text-neutral-400">Goal: {goal} • {experience} Level</p>
                    </div>

                    {/* Interactive BMI bar */}
                    <div className="w-full bg-neutral-950 rounded-2xl p-3 text-left">
                      <div className="flex justify-between items-center text-xs mb-1.5">
                        <span className="font-semibold text-neutral-400">BMI Index: {bmiValue}</span>
                        <span className={`font-bold ${bmiCat.color}`}>{bmiCat.text}</span>
                      </div>
                      <div className="w-full h-2 bg-neutral-850 rounded-full overflow-hidden flex">
                        <div className="w-[18%] bg-amber-400 h-full"></div>
                        <div className="w-[32%] bg-emerald-500 h-full"></div>
                        <div className="w-[25%] bg-orange-400 h-full"></div>
                        <div className="w-[25%] bg-red-500 h-full"></div>
                      </div>
                      <div className="flex justify-between text-[8px] text-neutral-500 mt-1 uppercase font-mono">
                        <span>18.5</span>
                        <span>25.0</span>
                        <span>30.0</span>
                      </div>
                    </div>
                  </div>

                  {/* Settings Schedule & reminders */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-4 space-y-3">
                    <h5 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Protocol Customization</h5>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center p-2.5 rounded-xl bg-neutral-950">
                        <div className="space-y-0.5">
                          <span className="text-xs font-semibold text-white">Daily Workout Reminders</span>
                          <p className="text-[10px] text-neutral-500">Scheduled trigger: 08:30 AM</p>
                        </div>
                        <button 
                          onClick={() => {
                            playBeep(900, 100);
                            speak("Custom reminder schedules registered.");
                          }}
                          className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 font-bold text-[10px]"
                        >
                          EDIT TIME
                        </button>
                      </div>

                      <div className="flex justify-between items-center p-2.5 rounded-xl bg-neutral-950">
                        <div className="space-y-0.5">
                          <span className="text-xs font-semibold text-white">Voice Coach Engine</span>
                          <p className="text-[10px] text-neutral-500">Audio synthetic speech feedback</p>
                        </div>
                        <button 
                          onClick={() => {
                            playBeep(1100, 100);
                            speak("Test sequence. Voice trainer is connected and operational.");
                          }}
                          className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 font-bold"
                        >
                          <Volume2 className="w-4 h-4 animate-bounce" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* FLOATING SYSTEM BOTTOM TAB BAR */}
            <div className={`border-t flex justify-around py-2.5 px-2 select-none z-10 transition-all ${
              theme === 'dark' ? 'bg-[#121318]/95 border-neutral-800/60' : 'bg-[#F8F9FE]/95 border-neutral-200'
            }`}>
              {[
                { id: 'home', label: 'Home', icon: Smartphone },
                { id: 'workouts', label: 'Workouts', icon: Play },
                { id: 'library', label: 'Library', icon: Dumbbell },
                { id: 'progress', label: 'Progress', icon: Trophy },
                { id: 'profile', label: 'Profile', icon: Settings }
              ].map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      const doTransition = () => {
                        setActiveTab(tab.id as any);
                        setCurrentScreen('home'); // clean transition out of complete overlay if needed
                        playBeep(700 + (isActive ? 100 : 0), 40);
                      };
                      if (activeTab !== tab.id) {
                        triggerInterstitialIfFree(doTransition);
                      } else {
                        doTransition();
                      }
                    }}
                    className="flex flex-col items-center gap-1 transition-all group focus:outline-none"
                  >
                    <div className={`p-1 px-3.5 rounded-full transition ${
                      isActive 
                        ? 'bg-[#34C759]/20 text-[#34C759]' 
                        : 'text-neutral-500 group-hover:text-neutral-400'
                    }`}>
                      <Icon className="w-5 h-5 stroke-[2.5]" />
                    </div>
                    <span className={`text-[9px] font-extrabold tracking-wide ${isActive ? 'text-[#34C759]' : 'text-neutral-500'}`}>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 4. ACTIVE SMART WORKOUT PLAYER */}
        {currentScreen === 'workout_player' && (
          <div className="flex-1 flex flex-col justify-between bg-gradient-to-b from-[#121318] to-[#0A0B0D] p-6 text-white text-center">
            
            {/* Player Header */}
            <div className="flex justify-between items-center border-b border-neutral-850 pb-4">
              <button 
                onClick={() => {
                  setPlayerState('paused');
                  setCurrentScreen('home');
                  speak("Workout paused. Keep focus.");
                }}
                className="flex items-center gap-1 text-xs text-neutral-400 hover:text-white"
              >
                <ChevronLeft className="w-4 h-4" /> Exit
              </button>
              <span className="text-xs font-bold tracking-widest text-emerald-400 uppercase">{playerWorkoutTitle}</span>
              <div className="w-5"></div>
            </div>

            {/* Exercise Details Card */}
            {playerExercises[activeExerciseIdx] ? (
              <div className="flex-1 flex flex-col justify-around py-4">
                {playerState === 'ready' ? (
                  // Elegant starting view: "when exercise is starting show description and below image of that exercise"
                  <div className="flex-1 flex flex-col justify-between space-y-4 max-w-sm mx-auto w-full animate-fade-in">
                    <div className="text-center space-y-1">
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
                        GET READY - SET {activeSetIdx + 1} OF {playerExercises[activeExerciseIdx].sets}
                      </span>
                      <h3 className="text-2xl font-black text-white mt-2">{playerExercises[activeExerciseIdx].name}</h3>
                    </div>

                    <div className="bg-neutral-900 border border-neutral-850 rounded-3xl p-5 text-left space-y-4 shadow-xl">
                      <div>
                        <span className="text-[10px] text-emerald-400 font-extrabold uppercase tracking-widest block mb-1">
                          Instructions & Description
                        </span>
                        <p className="text-xs text-neutral-200 leading-relaxed font-medium">
                          {playerExercises[activeExerciseIdx].instructions}
                        </p>
                      </div>

                      <div className="border-t border-neutral-800 pt-3">
                        <span className="text-[10px] text-neutral-400 font-extrabold uppercase tracking-widest block mb-2">
                          Exercise Reference Form
                        </span>
                        <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-neutral-800 shadow-inner">
                          <img 
                            src={playerExercises[activeExerciseIdx].image || CATEGORY_IMAGES[playerExercises[activeExerciseIdx].category] || DEFAULT_CATEGORY_IMAGE} 
                            alt={playerExercises[activeExerciseIdx].name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                          <span className="absolute bottom-2 left-3 text-[8px] font-black text-yellow-400 bg-black/60 px-1.5 py-0.5 rounded uppercase tracking-widest">
                            BIOMECHANICAL TARGET
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedDetailExercise(playerExercises[activeExerciseIdx]);
                        setPreviousScreenBeforeDetails('workout_player');
                        setCurrentScreen('exercise_details');
                        speak(`Opening elite form analysis for ${playerExercises[activeExerciseIdx].name}.`);
                      }}
                      className="w-full py-2.5 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/35 text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition active:scale-98"
                    >
                      <Sparkles className="w-3.5 h-3.5 fill-current animate-pulse text-amber-400" />
                      View Comprehensive Form Details
                    </button>

                    {!isPremium && (
                      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-2.5 text-center">
                        <span className="text-[10px] font-bold text-amber-400 flex items-center justify-center gap-1">
                          <Lock className="w-3.5 h-3.5" /> Free tier: first {Math.max(1, Math.ceil(playerExercises.length * 0.3))} of {playerExercises.length} exercises unlocked.
                        </span>
                      </div>
                    )}

                    {/* Mock Heart Rate Monitor Widget */}
                    <div className="bg-neutral-950/60 border border-neutral-900/60 rounded-2xl p-3 flex items-center justify-between gap-3 shadow-md">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <Heart className={`w-5 h-5 text-red-500 fill-current ${playerState === 'playing' ? 'animate-pulse' : ''}`} style={{ animationDuration: `${60 / heartRate}s` }} />
                          {playerState === 'playing' && (
                            <span className="absolute -top-1 -right-1 flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                            </span>
                          )}
                        </div>
                        <div className="text-left">
                          <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold block">Heart Rate</span>
                          <div className="flex items-baseline gap-1">
                            <span className="text-base font-black text-white font-mono leading-none">{heartRate}</span>
                            <span className="text-[9px] text-neutral-400 font-bold uppercase font-mono">BPM</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[8px] uppercase tracking-wider text-neutral-500 font-bold block mb-0.5">Intensity Zone</span>
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          hrIntensity === 'low' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                          hrIntensity === 'moderate' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                          hrIntensity === 'high' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {hrIntensity === 'low' && 'Warm up'}
                          {hrIntensity === 'moderate' && 'Fat Burn'}
                          {hrIntensity === 'high' && 'Cardio'}
                          {hrIntensity === 'peak' && 'Peak zone'}
                        </span>
                      </div>
                    </div>

                    {/* Status metrics bar */}
                    <div className="grid grid-cols-2 gap-4 text-center border-t border-b border-neutral-850 py-3">
                      <div>
                        <span className="block text-xs text-neutral-500 uppercase font-bold tracking-wider">Target Reps</span>
                        <span className="text-base font-black text-white">{playerExercises[activeExerciseIdx].reps}</span>
                      </div>
                      <div>
                        <span className="block text-xs text-neutral-500 uppercase font-bold tracking-wider">Current Set</span>
                        <span className="text-base font-black text-white">Set {activeSetIdx + 1} / {playerExercises[activeExerciseIdx].sets}</span>
                      </div>
                    </div>

                    <div className="flex justify-center pt-2">
                      <button
                        onClick={() => {
                          setPlayerState('playing');
                          speak(`Starting ${playerExercises[activeExerciseIdx].name}. Focus on posture symmetry.`);
                        }}
                        className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white font-extrabold uppercase tracking-wider shadow shadow-emerald-950 transition duration-150"
                      >
                        START SET
                      </button>
                    </div>
                  </div>
                ) : (
                  // Active workout playing, resting, or paused view
                  <>
                    <div className="space-y-1 animate-fade-in">
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2.5 py-0.5 rounded-full uppercase">
                        Exercise {activeExerciseIdx + 1} of {playerExercises.length}
                      </span>
                      <h3 className="text-2xl font-black">{playerExercises[activeExerciseIdx].name}</h3>
                      <p className="text-xs text-neutral-400 max-w-xs mx-auto">{playerExercises[activeExerciseIdx].instructions}</p>
                    </div>

                    {/* Active Exercise Live Demonstration (Interactive CSS + Real Photo) */}
                    <div className="bg-neutral-950/80 border border-neutral-900 rounded-2xl max-w-xs mx-auto w-full h-24 grid grid-cols-2 overflow-hidden relative mt-2 shadow-inner">
                      <div className="relative h-full w-full">
                        <img 
                          src={playerExercises[activeExerciseIdx].image || CATEGORY_IMAGES[playerExercises[activeExerciseIdx].category] || DEFAULT_CATEGORY_IMAGE} 
                          alt={playerExercises[activeExerciseIdx].name}
                          className="absolute inset-0 w-full h-full object-cover opacity-85"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-neutral-950"></div>
                        <span className="absolute left-2.5 top-1.5 text-[7px] font-black text-white bg-black/60 px-1.5 py-0.5 rounded uppercase tracking-wider">
                          FORM TARGET
                        </span>
                      </div>
                      <div className="flex items-center justify-center relative h-full">
                        <span className="absolute right-2.5 top-1.5 text-[7px] font-bold text-neutral-500 uppercase font-mono tracking-widest">
                          KINETIC TRACKER
                        </span>
                        {renderExerciseVisual(playerExercises[activeExerciseIdx].category)}
                      </div>
                    </div>

                    {!isPremium && (
                      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-2.5 max-w-xs mx-auto text-center my-1.5">
                        <span className="text-[10px] font-bold text-amber-400 flex items-center justify-center gap-1">
                          <Lock className="w-3.5 h-3.5" /> Free tier: first {Math.max(1, Math.ceil(playerExercises.length * 0.3))} of {playerExercises.length} exercises unlocked.
                        </span>
                      </div>
                    )}

                    {/* Countdown Circle */}
                    <div className="flex justify-center my-6">
                      <div className="w-44 h-44 rounded-full border-4 border-emerald-500/10 flex flex-col items-center justify-center relative shadow-lg shadow-emerald-950/20 animate-fade-in">
                        {/* Pulsing decoration circle inside */}
                        <div className="absolute inset-2 border border-emerald-500/20 rounded-full animate-ping opacity-10"></div>
                        
                        {playerState === 'playing' ? (
                          <>
                            <span className="text-4xl font-extrabold tracking-tight text-white">{playerTimer}</span>
                            <span className="text-[10px] text-emerald-400 font-bold uppercase mt-1 tracking-wider">Seconds Left</span>
                          </>
                        ) : playerState === 'rest' ? (
                          <>
                            <span className="text-4xl font-extrabold tracking-tight text-yellow-400">{playerTimer}</span>
                            <span className="text-[10px] text-yellow-400 font-bold uppercase mt-1 tracking-wider">RESTING</span>
                          </>
                        ) : (
                          <>
                            <span className="text-2xl font-bold text-[#A8C7FA]">READY</span>
                            <span className="text-[10px] text-[#A8C7FA] font-semibold mt-1">Set {activeSetIdx + 1} of {playerExercises[activeExerciseIdx].sets}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Mock Heart Rate Monitor Widget */}
                    <div className="bg-neutral-950/60 border border-neutral-900/60 rounded-2xl max-w-xs mx-auto w-full p-3 flex items-center justify-between gap-3 shadow-md">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <Heart className={`w-5 h-5 text-red-500 fill-current ${playerState === 'playing' ? 'animate-pulse' : ''}`} style={{ animationDuration: `${60 / heartRate}s` }} />
                          {playerState === 'playing' && (
                            <span className="absolute -top-1 -right-1 flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                            </span>
                          )}
                        </div>
                        <div className="text-left">
                          <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold block">Heart Rate</span>
                          <div className="flex items-baseline gap-1">
                            <span className="text-base font-black text-white font-mono leading-none">{heartRate}</span>
                            <span className="text-[9px] text-neutral-400 font-bold uppercase font-mono">BPM</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[8px] uppercase tracking-wider text-neutral-500 font-bold block mb-0.5">Intensity Zone</span>
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          hrIntensity === 'low' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                          hrIntensity === 'moderate' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                          hrIntensity === 'high' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {hrIntensity === 'low' && 'Warm up'}
                          {hrIntensity === 'moderate' && 'Fat Burn'}
                          {hrIntensity === 'high' && 'Cardio'}
                          {hrIntensity === 'peak' && 'Peak zone'}
                        </span>
                      </div>
                    </div>

                    {/* Status metrics bar */}
                    <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto text-center border-t border-b border-neutral-850 py-3">
                      <div>
                        <span className="block text-xs text-neutral-500 uppercase">Target Reps</span>
                        <span className="text-base font-bold text-white">{playerExercises[activeExerciseIdx].reps}</span>
                      </div>
                      <div>
                        <span className="block text-xs text-neutral-500 uppercase">Current Set</span>
                        <span className="text-base font-bold text-white">Set {activeSetIdx + 1} / {playerExercises[activeExerciseIdx].sets}</span>
                      </div>
                    </div>

                    {/* Player actions */}
                    <div className="flex justify-center items-center gap-5 mt-4">
                      {playerState === 'rest' ? (
                        <button 
                          onClick={skipRest}
                          className="py-3 px-8 rounded-2xl bg-yellow-500 text-black font-extrabold text-sm shadow hover:bg-yellow-400"
                        >
                          SKIP REST INTERVAL
                        </button>
                      ) : (
                        <>
                          {playerState === 'playing' && (
                            <button
                              onClick={() => {
                                setPlayerState('paused');
                                speak("Workout suspended.");
                              }}
                              className="w-40 py-3.5 rounded-2xl bg-neutral-850 hover:bg-neutral-800 text-neutral-300 font-bold"
                            >
                              PAUSE SESSION
                            </button>
                          )}

                          {playerState === 'paused' && (
                            <button
                              onClick={() => {
                                setPlayerState('playing');
                                speak("Resuming training protocol.");
                              }}
                              className="w-40 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold"
                            >
                              RESUME WORKOUT
                            </button>
                          )}

                          {/* Manual Skip button */}
                          <button
                            onClick={handleExerciseStepComplete}
                            className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-300 font-bold text-xs"
                          >
                            SKIP SET
                          </button>
                        </>
                      )}
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="py-20 text-neutral-400 text-sm">Error syncing training buffer.</div>
            )}
          </div>
        )}

        {/* 5. KEGEL ISOMETRIC ACTIVE PLAYER */}
        {currentScreen === 'kegel_player' && (
          <div className="flex-1 flex flex-col justify-between bg-gradient-to-b from-[#1C152B] to-[#0D0A14] p-6 text-white text-center">
            
            {/* Header */}
            <div className="flex justify-between items-center border-b border-purple-900/40 pb-4">
              <button 
                onClick={() => {
                  setPlayerState('paused');
                  setCurrentScreen('home');
                  speak("Kegel isometric pause. Maintain baseline breathing.");
                }}
                className="flex items-center gap-1 text-xs text-neutral-400"
              >
                <ChevronLeft className="w-4 h-4" /> Exit
              </button>
              <span className="text-xs font-bold tracking-widest text-purple-400 uppercase">Pelvic Floor Squeeze</span>
              <div className="w-5"></div>
            </div>

            {/* Rhythmic Breathing Expansion Ring */}
            <div className="flex-1 flex flex-col justify-around py-4">
              <div className="space-y-1">
                <span className="text-[10px] bg-purple-500/20 text-purple-300 font-bold px-3 py-0.5 rounded-full uppercase">
                  Reps Left: {kegelRepsRemaining}
                </span>
                <h3 className="text-2xl font-black capitalize">{kegelMode === 'squeeze' ? 'SQUEEZE AND HOLD!' : 'RELAX AND BREATHE'}</h3>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  {kegelMode === 'squeeze' ? 'Pull up and contract pelvic base muscles tightly.' : 'Fully release base muscles, inhale deeply into your abdomen.'}
                </p>
              </div>

              {/* Contraction Visual Expander */}
              <div className="flex justify-center my-6">
                <div className={`w-48 h-48 rounded-full flex flex-col items-center justify-center transition-all duration-[2000ms] border-4 ${
                  kegelMode === 'squeeze' 
                    ? 'bg-purple-500/20 border-purple-400 scale-105 shadow-2xl shadow-purple-900/50' 
                    : 'bg-purple-950/10 border-purple-800 scale-95'
                }`}>
                  <span className="text-5xl font-black text-white">{playerTimer}s</span>
                  <span className="text-[9px] text-purple-300 tracking-wider font-bold mt-1 uppercase">
                    {kegelMode === 'squeeze' ? 'ISOMETRIC HOLD' : 'REST INTERVAL'}
                  </span>
                </div>
              </div>

              <div className="flex justify-center items-center gap-4">
                {playerState === 'ready' ? (
                  <button
                    onClick={() => {
                      setPlayerState('playing');
                      setKegelMode('relax');
                      setPlayerTimer(3);
                      speak("Kegel isometric train active. Breathe in to prepare.");
                    }}
                    className="w-44 py-4 rounded-2xl bg-purple-500 hover:bg-purple-600 font-bold shadow-lg shadow-purple-950/30 text-white"
                  >
                    START TRAINER
                  </button>
                ) : (
                  <>
                    {playerState === 'playing' ? (
                      <button 
                        onClick={() => {
                          setPlayerState('paused');
                          speak("Training suspended.");
                        }}
                        className="w-40 py-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-400 font-bold"
                      >
                        PAUSE
                      </button>
                    ) : (
                      <button 
                        onClick={() => {
                          setPlayerState('playing');
                          speak("Resuming rhythmic compressions.");
                        }}
                        className="w-40 py-3.5 rounded-2xl bg-purple-500 text-white font-bold"
                      >
                        RESUME
                      </button>
                    )}
                    <button 
                      onClick={handleKegelWorkoutComplete}
                      className="p-3.5 rounded-2xl bg-neutral-950 text-neutral-300 font-semibold text-xs"
                    >
                      FINISH EARLY
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 4.5 PREMIUM EXERCISE DETAILS SCREEN */}
        {currentScreen === 'exercise_details' && selectedDetailExercise && (
          <ExerciseDetailsPage
            exerciseName={selectedDetailExercise.name}
            onBack={() => {
              if (previousScreenBeforeDetails === 'workout_player') {
                setCurrentScreen('workout_player');
                speak("Returning to active training session.");
              } else {
                setCurrentScreen('home');
                speak("Returning to library.");
              }
            }}
            onStartExercise={() => {
              // Launch this specific exercise immediately as an individual workout
              launchWorkout(`Individual: ${selectedDetailExercise.name}`, [selectedDetailExercise]);
            }}
            isFavorite={favorites.includes(selectedDetailExercise.name)}
            onToggleFavorite={() => toggleFavorite(selectedDetailExercise.name)}
            theme={theme}
            isPremium={isPremium}
            onUpgrade={() => setShowPremiumModal(true)}
          />
        )}

        {/* ADMOB ROTATING BANNER AD (ONLY FOR FREE USERS & SELECTED SCREENS) */}
        {!isPremium && admobVisible && (currentScreen === 'home' || currentScreen === 'workout_complete' || currentScreen === 'exercise_details') && (
          <div className="bg-neutral-900 border-t border-neutral-850 px-3 py-1.5 flex items-center justify-between gap-2 text-xs relative select-none animate-fade-in shrink-0">
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="bg-yellow-500/20 text-yellow-400 text-[8px] px-1 py-0.5 rounded border border-yellow-500/30 font-bold uppercase tracking-wider scale-95 shrink-0">Ad</span>
              <div className="text-left leading-tight overflow-hidden">
                <p className="font-extrabold text-[11px] text-white truncate">{MOCK_ADS[activeAdIdx].title}</p>
                <p className="text-[9px] text-neutral-400 truncate">
                  {admobManager.isDeviceOffline() 
                    ? "Network offline. Reconnecting..." 
                    : `${MOCK_ADS[activeAdIdx].desc} | ID: ${ADMOB_IDS.BANNER_UNIT_ID}`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button 
                onClick={() => window.open(MOCK_ADS[activeAdIdx].url, '_blank')}
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-[9px] px-2.5 py-1 rounded-md shadow uppercase tracking-wider whitespace-nowrap"
              >
                {MOCK_ADS[activeAdIdx].btnText}
              </button>
              <button 
                onClick={() => {
                  setShowPremiumModal(true);
                  speak("Tired of ads? Upgrade to FitMaster Pro to enjoy an ad-free premium training session!");
                }}
                className="text-neutral-500 hover:text-white p-1"
                title="Remove Ads"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* BOTTOM NAV BAR DECORATOR FOR ANDROID */}
        <div className="py-2 flex justify-center bg-transparent z-10 transition-colors select-none">
          <div className="w-32 h-1 bg-current opacity-40 rounded-full"></div>
        </div>

      </div>

      {/* ADMOB INTERSTITIAL AD OVERLAY */}
      {showAdInterstitial && (
        <div className="fixed inset-0 bg-[#0F1014]/95 backdrop-blur-md z-50 flex items-center justify-center p-5 select-none animate-fade-in text-white">
          <div className="bg-gradient-to-b from-[#1C1D24] to-[#0F1014] border border-neutral-800 rounded-3xl max-w-sm w-full p-6 flex flex-col relative overflow-hidden shadow-2xl">
            <div className="flex justify-between items-center mb-4">
              <div className="flex flex-col gap-0.5 text-left">
                <div className="flex items-center gap-1.5">
                  <span className="bg-amber-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded tracking-widest uppercase">AdMob</span>
                  <span className="text-[10px] text-neutral-400 uppercase font-mono tracking-widest font-bold">Interstitial</span>
                </div>
                <span className="text-[8px] text-neutral-500 font-mono truncate max-w-[150px]" title={ADMOB_IDS.INTERSTITIAL_UNIT_ID}>
                  ID: {ADMOB_IDS.INTERSTITIAL_UNIT_ID}
                </span>
              </div>
              {adCountdown > 0 ? (
                <span className="text-xs text-neutral-400 bg-neutral-950 px-2.5 py-1 rounded-full font-mono">
                  Skip in {adCountdown}s
                </span>
              ) : (
                <button
                  onClick={() => {
                    setShowAdInterstitial(false);
                    if (pendingAction) {
                      pendingAction();
                      setPendingAction(null);
                    }
                  }}
                  className="flex items-center gap-1 text-xs font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full hover:bg-emerald-500/20 active:scale-95 transition"
                >
                  Close Ad <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="rounded-xl overflow-hidden h-44 mb-4 relative">
              <img 
                src={interstitialAdData.image} 
                alt={interstitialAdData.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <span className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-xs text-[8px] font-black tracking-widest uppercase text-yellow-400 px-1.5 py-0.5 rounded">
                Sponsored by Google
              </span>
            </div>

            <h3 className="text-lg font-black text-white leading-snug">{interstitialAdData.title}</h3>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">{interstitialAdData.desc}</p>

            <button
              onClick={() => {
                window.open(interstitialAdData.actionUrl, '_blank');
              }}
              className="w-full mt-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-xs shadow-lg uppercase tracking-wider transition duration-300"
            >
              Learn More / Install Now
            </button>

            <button
              onClick={() => {
                setShowAdInterstitial(false);
                setShowPremiumModal(true);
                speak("Upgrade to FitMaster Pro to completely bypass ads and support India's offline wellness engineering.");
              }}
              className="mt-3 text-[10px] font-bold text-amber-400/80 hover:text-amber-300 text-center uppercase tracking-widest font-mono"
            >
              ⚡ Remove Ads with FitMaster Pro
            </button>
          </div>
        </div>
      )}

      {/* 6. GO PREMIUM CELESTIAL POPUP MODAL */}
      {showPremiumModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-b from-[#1E202B] to-[#12131A] rounded-[32px] p-6 text-white border border-neutral-800 max-w-sm w-full text-center relative overflow-hidden shadow-2xl">
            <div className="absolute top-[-30px] right-[-30px] w-36 h-36 bg-[#FFB300]/10 rounded-full blur-2xl"></div>
            
            <button 
              onClick={() => {
                setShowPremiumModal(false);
                playBeep(600, 100);
              }}
              className="absolute right-4 top-4 text-neutral-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex justify-center mb-3">
              <div className="w-14 h-14 bg-amber-500/10 rounded-full flex items-center justify-center border border-amber-500/30">
                <Crown className="w-7 h-7 text-amber-400 fill-amber-400 animate-pulse" />
              </div>
            </div>

            <h3 className="text-xl font-black text-white">Unlock FitMaster Pro</h3>
            <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
              Upgrade to unleash full biomorphic simulation and elite Gemini customized athletic training regimens.
            </p>

            <div className="space-y-3.5 my-5 text-left text-xs font-semibold">
              <div className="flex items-center gap-2.5 bg-neutral-900/60 p-2.5 rounded-xl">
                <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                <div>
                  <span className="block text-white">Remove Interstitial Banner Ads</span>
                  <span className="text-[10px] text-neutral-500">100% focus on kinetic progress.</span>
                </div>
              </div>
              <div className="flex items-center gap-2.5 bg-neutral-900/60 p-2.5 rounded-xl">
                <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                <div>
                  <span className="block text-white">Advanced Heavy Gym Cycles</span>
                  <span className="text-[10px] text-neutral-500">Unlocks dumbbell and gym barbell hypertrophy.</span>
                </div>
              </div>
              <div className="flex items-center gap-2.5 bg-neutral-900/60 p-2.5 rounded-xl">
                <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
                <div>
                  <span className="block text-white">Comprehensive 300+ Exercise Library</span>
                  <span className="text-[10px] text-neutral-500">Interactive HD muscle Contours.</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => {
                  setIsPremium(true);
                  setShowPremiumModal(false);
                  playBeep(1200, 300);
                  speak("Namaste, welcome to FitMaster Pro. Under Indian Special plan, your full premium suite is unlocked.");
                }}
                className="w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-extrabold text-xs hover:opacity-95 shadow-md flex items-center justify-between transition-transform active:scale-[0.98]"
              >
                <span className="flex items-center gap-1.5">🇮🇳 INDIA REGION</span>
                <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] font-black">₹100/mo</span>
              </button>
              
              <button
                onClick={() => {
                  setIsPremium(true);
                  setShowPremiumModal(false);
                  playBeep(1200, 300);
                  speak("Access granted. Pro features unlocked successfully. Welcome to FitMaster Pro.");
                }}
                className="w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-extrabold text-xs hover:opacity-95 shadow-md flex items-center justify-between transition-transform active:scale-[0.98]"
              >
                <span className="flex items-center gap-1.5">🌍 INTERNATIONAL</span>
                <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] font-black">$3/mo</span>
              </button>
            </div>
            <span className="block text-[9px] text-neutral-500 mt-2.5 uppercase tracking-widest font-mono">
              SECURE PAYMENTS • CANCEL ANYTIME
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
