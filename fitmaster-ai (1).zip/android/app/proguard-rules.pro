# Add project specific ProGuard rules here.
# You can control what gets obfuscated or kept.
-keepattributes Signature
-keepattributes *Annotation*
